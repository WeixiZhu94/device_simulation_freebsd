/********1*********2*********3*********4*********5**********6*********7*********/
/*                                                                             */
/*  PRODUCT      : MAD Device Simulation Framework                             */
/*  COPYRIGHT    : (c) 2013 HTF Consulting                                     */
/*                                                                             */
/* This source code is provided by exclusive license for non-commercial use to */
/* XYZ Company                                                                 */
/*                                                                             */ 
/*******************************************************************************/
/*                                                                             */
/* Exe file ID  : MadBus.sys, MadDevice.sys                                    */ 
/*                                                                             */
/*  Module  NAME : MadBusDdiQi.h                                               */
/*                                                                             */
/*  DESCRIPTION  : Device-Driver-Interface definitions for the query_interface */
/*                 irp                                                         */
/*                 Drived from WDK-Toaster\bus\driver.h                        */
/*                                                                             */
/*******************************************************************************/

#ifndef __DRIVER_H
#define __DRIVER_H

//
// Define Interface reference/dereference routines for
//  Interfaces exported by IRP_MN_QUERY_INTERFACE
//

typedef VOID (*PINTERFACE_REFERENCE)(PVOID Context);
typedef VOID (*PINTERFACE_DEREFERENCE)(PVOID Context);

typedef
BOOLEAN
(*PMADDEVICE_GET_POWER_LEVEL)(
                           IN   PVOID Context,
                           OUT  PUCHAR Level
                               );

typedef
BOOLEAN
(*PMADDEVICE_SET_POWER_LEVEL)(
                           IN   PVOID Context,
                           OUT  UCHAR Level
                               );

typedef
BOOLEAN
(*PMADDEVICE_IS_CHILD_PROTECTED)(
                             IN PVOID Context
                             );

//
// Interface for getting and setting power level etc.,
//
typedef struct _MADDEVICE_INTERFACE_STANDARD {
    INTERFACE                        InterfaceHeader;
    PMADDEVICE_GET_POWER_LEVEL    GetPowerLevel;
    PMADDEVICE_SET_POWER_LEVEL    SetPowerLevel;
    PMADDEVICE_IS_CHILD_PROTECTED      IsSafetyLockEnabled; //):
} MADDEVICE_INTERFACE_STANDARD, *PMADDEVICE_INTERFACE_STANDARD;


#endif

