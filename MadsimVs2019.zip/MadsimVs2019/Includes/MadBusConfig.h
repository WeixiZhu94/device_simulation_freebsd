/********1*********2*********3*********4*********5**********6*********7*********/
/*                                                                             */
/*  PRODUCT      : MAD Device Simulation Framework                             */
/*  COPYRIGHT    : (c) 2013 HTF Consulting                                     */
/*                                                                             */
/* This source code is provided by exclusive license for non-commercial use to */
/* XYZ Company                                                                 */
/*                                                                             */ 
/*******************************************************************************/
/*                                                                             */
/*  Exe file ID  : MadBus.sys, MadDevice.sys                                   */ 
/*                                                                             */
/*                                                                             */
/*  Module  NAME : MadBusConfig.h                                              */
/*                                                                             */
/*  DESCRIPTION  : Definitions and structures defining the configuration space */
/*                 for the Mad Bus                                             */
/*                                                                             */
/*******************************************************************************/

#define MAD_VENDOR_ID         0x9808 //Write it out on a sheet of paper & then rotate it upside down
#define MAD_DEVICE_ID         0x1001
#define MAD_SUBVENDOR_ID      MAD_VENDOR_ID
#define MAD_SUBSYSTEM_ID      MAD_DEVICE_ID

//Our config space is just an alias of good old PCI - plus extra data
//
#define MADBUS_WHICHSPACE_CONFIG     PCI_WHICHSPACE_CONFIG

//Define an interrupt-related parm area for the simulation interrupt thread 
//won't compile w/out WDK/Kmdf
//

typedef struct _MAD_SIMULATION_INT_PARMS
    {
	WDFINTERRUPT              hInterrupt;
	WDFSPINLOCK               hSpinlock;
	KIRQL                     Irql;
	KAFFINITY                 IntAffinity;
	PFN_WDF_INTERRUPT_ISR     pMadEvtIsrFunxn;
	KEVENT                    evDevPowerUp;
	KEVENT                    evDevPowerDown;
	PKEVENT                   pEvIntThreadExit;
    } MAD_SIMULATION_INT_PARMS, *PMAD_SIMULATION_INT_PARMS;

#ifdef KMDF_WONT_CREATE_DMA_ENABLER 
typedef NTSTATUS DMA_ENABLER_CREATE(IN WDFDEVICE Device, IN PWDF_DMA_ENABLER_CONFIG Config,
                                    IN OPTIONAL PWDF_OBJECT_ATTRIBUTES Attributes, OUT WDFDMAENABLER* DmaEnablerHandle);
typedef DMA_ENABLER_CREATE          *PFN_DMA_ENABLER_CREATE;
//
typedef VOID DMA_ENABLER_SET_MAX_SG_ELEMS(IN WDFDMAENABLER DmaEnabler, IN size_t MaximumFragments);
typedef      DMA_ENABLER_SET_MAX_SG_ELEMS *PFN_DMA_ENABLER_SET_MAX_SG_ELEMS;
//
typedef NTSTATUS   DMA_TRANSACTION_CREATE(IN WDFDMAENABLER DmaEnabler, IN OPTIONAL WDF_OBJECT_ATTRIBUTES *Attributes, OUT WDFDMATRANSACTION *DmaTransaction);
typedef            DMA_TRANSACTION_CREATE       *PFN_DMA_TRANSACTION_CREATE;
//
typedef NTSTATUS   DMA_TRANSACTION_INIT_FROM_REQUEST(IN WDFDMATRANSACTION DmaTransaction, IN WDFREQUEST Request, 
	                                                 IN PFN_WDF_PROGRAM_DMA EvtProgramDmaFunction, IN WDF_DMA_DIRECTION DmaDirection);
typedef            DMA_TRANSACTION_INIT_FROM_REQUEST *PFN_DMA_TRANSACTION_INIT_FROM_REQ;
//
typedef NTSTATUS   DMA_TRANSACTION_EXECUTE(IN WDFDMATRANSACTION DmaTransaction, IN OPTIONAL PVOID Context);
typedef            DMA_TRANSACTION_EXECUTE   *PFN_DMA_TRANSACTION_EXECUTE;
//
typedef WDFREQUEST DMA_TRANSACTION_GET_REQUEST(IN WDFDMATRANSACTION DmaTransaction);
typedef            DMA_TRANSACTION_GET_REQUEST *PFN_DMA_TRANSACTION_GET_REQUEST;
//
typedef size_t     DMA_TRANSACTION_GET_BYTES_XFERD(IN WDFDMATRANSACTION DmaTransaction);
typedef            DMA_TRANSACTION_GET_BYTES_XFERD *PFN_DMA_TRANSACTION_GET_BYTES_XFERD;
//
typedef BOOLEAN    DMA_TRANSACTION_DMA_COMPLETED(IN WDFDMATRANSACTION DmaTransaction, OUT NTSTATUS *Status);
typedef            DMA_TRANSACTION_DMA_COMPLETED  *PFN_DMA_TRANSACTION_DMA_COMPLETED;

typedef WDFDEVICE  DMA_TRANSACION_GET_DEVICE(IN WDFDMATRANSACTION  DmaTransaction);
typedef            DMA_TRANSACION_GET_DEVICE *PFN_DMA_TRANSACTION_GET_DEVICE;

typedef struct _MADSIM_KMDF_DMA_FUNXNS
    {
	PFN_DMA_ENABLER_CREATE                           pDmaEnablerCreate;
	PFN_DMA_ENABLER_SET_MAX_SG_ELEMS                 pDmaSetMaxSgElems;
	PFN_DMA_TRANSACTION_CREATE                       pDmaXaxnCreate;
	PFN_DMA_TRANSACTION_INIT_FROM_REQ                pDmaXaxnInitFromReq;
	PFN_DMA_TRANSACTION_EXECUTE                      pDmaXaxnExecute;
	PFN_DMA_TRANSACTION_GET_REQUEST                  pDmaXaxnGetRequest;
	PFN_DMA_TRANSACTION_GET_BYTES_XFERD              pDmaXaxnGetBytesXferd;
	PFN_DMA_TRANSACTION_DMA_COMPLETED                pDmaXaxnCompleted;
	//PFN_DMA_TRANSACTION_GET_DEVICE                   pDmaXaxnGetDevice;
    } MADSIM_KMDF_DMA_FUNXNS, *PMADSIM_KMDF_DMA_FUNXNS;
#endif //KMDF_WONT_CREATE_DMA_ENABLER 
//
typedef struct _VENDOR_SPECIFIC_DATA
               {
			   ULONG                     BusSlotNum;
			   MAD_DEV_INT_MODE          IntMode;
               PHYSICAL_ADDRESS          liLoAddr;
               PHYSICAL_ADDRESS          liHiAddr;
			   KIRQL                     Irql;
               DEVICE_POWER_STATE        DevPowerState;
               PMAD_SIMULATION_INT_PARMS pMadSimIntParms;
               
               #ifdef KMDF_WONT_CREATE_DMA_ENABLER 
			   PMADSIM_KMDF_DMA_FUNXNS pMadSimDmaFunxns;
               #endif
               } VENDOR_SPECIFIC_DATA, *PVENDOR_SPECIFIC_DATA;
#define  VENDOR_SPEC_DATA_SIZE    sizeof(VENDOR_SPECIFIC_DATA)
//
typedef struct _MADBUS_DEVICE_CONFIG_DATA
               {
               PCI_COMMON_CONFIG    LegacyPci; 
               // 
               VENDOR_SPECIFIC_DATA VndrSpecData;
               //
               UCHAR                Filler[MAD_SECTOR_SIZE - sizeof(PCI_COMMON_CONFIG) - VENDOR_SPEC_DATA_SIZE];       
               }  MADBUS_DEVICE_CONFIG_DATA, *PMADBUS_DEVICE_CONFIG_DATA;
#define  MADBUS_DEV_CNFG_SIZE       sizeof(MADBUS_DEVICE_CONFIG_DATA)

// CONFIG_SPACE default init funxn to be compiled only once & only in the Bus driver
#ifdef _MADBUS_MAIN /////////////////////////////////////////////////////////////////////
void Dflt_Init_Config_Space(PMADBUS_DEVICE_CONFIG_DATA pMadDevCnfg)

{
    RtlFillMemory((PVOID)pMadDevCnfg, sizeof(MADBUS_DEVICE_CONFIG_DATA), 0x00);

    pMadDevCnfg->LegacyPci.VendorID = MAD_VENDOR_ID;                   
    pMadDevCnfg->LegacyPci.DeviceID = MAD_DEVICE_ID;                   
    //USHORT  Command;                    
    //USHORT  Status;
    //UCHAR   RevisionID;                 
    //UCHAR   ProgIf;                     
    //UCHAR   SubClass;                   
    //UCHAR   BaseClass;                  
    //UCHAR   CacheLineSize;              
    //UCHAR   LatencyTimer;               
    //UCHAR   HeaderType;                 
    //UCHAR   BIST;                       

    pMadDevCnfg->LegacyPci.u.type0.BaseAddresses[0] = 0xFFF00000;
    pMadDevCnfg->LegacyPci.u.type0.BaseAddresses[1] = 0xFFF10000;
    pMadDevCnfg->LegacyPci.u.type0.BaseAddresses[2] = 0xFFF20000;
    pMadDevCnfg->LegacyPci.u.type0.BaseAddresses[3] = 0xFFF30000;
    pMadDevCnfg->LegacyPci.u.type0.BaseAddresses[4] = 0xFFF40000;
    pMadDevCnfg->LegacyPci.u.type0.BaseAddresses[5] = 0xFFF50000;
    //ULONG   CIS;
    pMadDevCnfg->LegacyPci.u.type0.SubVendorID      = MAD_SUBVENDOR_ID; 
    pMadDevCnfg->LegacyPci.u.type0.SubSystemID      = MAD_SUBSYSTEM_ID; 
    //        ULONG   ROMBaseAddress;
    //        UCHAR   CapabilitiesPtr;
    //        UCHAR   Reserved1[3];
    //        ULONG   Reserved2;
    pMadDevCnfg->LegacyPci.u.type0.InterruptLine    = 0x0A;
    pMadDevCnfg->LegacyPci.u.type0.InterruptPin     = 0x01;
    //       UCHAR   MinimumGrant;       
    //       UCHAR   MaximumLatency;     

    return;
}
#endif //_MADBUS_MAIN /////////////////////////////////////////////////////////////////
