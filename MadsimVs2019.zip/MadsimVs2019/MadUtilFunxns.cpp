/********1*********2*********3*********4*********5**********6*********7*********/
/*                                                                             */
/*  PRODUCT      : MAD Device Simulation Framework                             */
/*  COPYRIGHT    : (c) 2022 HTF Consulting                                     */
/*                                                                             */
/* This source code is provided by exclusive license for non-commercial use to */
/* XYZ Company                                                                 */
/*                                                                             */
/*******************************************************************************/
/*                                                                             */
/*  Exe file ID  : MadBus.sys, MadDevice.sys                                   */
/*                                                                             */
/*  Module  NAME : MadUtilFunxns.cpp                                           */
/*                                                                             */
/*  DESCRIPTION  : Utility functions for the drivers                           */
/*                                                                             */
/*******************************************************************************/


#define BYTE UCHAR

//extern "C" {
#include ".\MadBus\MadBus.h"
//#include <ntddk.h>
//#include <wdf.h>
#define NTSTRSAFE_LIB
#include <ntstrsafe.h>
#include <ntintsafe.h>
//
#include "Includes\MadDefinition.h"
#include "Includes\MadUtilFunxns.h"

#ifdef WPP_TRACING
    #ifdef MADDEVICE
	#include "MadDevEtw.h"
    #else
    #include "MadBusEtw.h"
    #endif
	#include "MadUtilFunxns.tmh"
#endif
//}

extern PDRIVER_OBJECT gpDrivrObj;

/************************************************************************//**
 * Mad_MapSysAddr2UsrAddr
 *
 * DESCRIPTION:
 *      Given a system logical address, maps this address into a user mode
 *      process's address space
 *      Assume logical address passed to this routine points to a contiguous
 *      buffer large enough to contain the buffer requested.
 *      This routine must be called at DISPATCH level from the context of the
 *      Application thread.  
 *    
 * PARAMETERS: 
 *     @param[in]  pKrnlAddr    pointer to the buffer in kernel addr. space
 *     @param[in]  Len2Map      length to map
 *     @param[in]  ppPhysAddr   pointer to a pointer to the physical address
 *                              of the buffer  
 *     @param[in]  ppMapdMemUsr pointer to the user mode mapped buffer
 *     
 * RETURNS:
 *    @return      NtStatus    indicates success or reason for the failure
 * 
 ***************************************************************************/
NTSTATUS Mad_MapSysAddr2UsrAddr(IN PVOID pKrnlAddr, IN /*ULONG*/ size_t Len2Map,
                                OUT PHYSICAL_ADDRESS* pPhysAddr, OUT PVOID* ppMapdMemUsr)

{
PHYSICAL_ADDRESS   liPhysAddr;
size_t             ViewSize;
size_t             CommitSize;
UNICODE_STRING     UniStrPhysMem;
OBJECT_ATTRIBUTES  ObjAttrs;
HANDLE             hPhysMemory  = NULL;
PVOID              pPhysMemSexn = NULL;
NTSTATUS           NtStatus;
PHYSICAL_ADDRESS   liPhysAddrBase;
PHYSICAL_ADDRESS   liPhysAddrEnd;
PHYSICAL_ADDRESS   liViewBase;
PHYSICAL_ADDRESS   MapdLen;
ULONG_PTR          VirtAddr;
 
    liPhysAddr    = MmGetPhysicalAddress(pKrnlAddr);
    *pPhysAddr    = liPhysAddr;
	*ppMapdMemUsr = NULL;

// Get a pointer to physical memory...
//
// - Create the name
// - Initialize the data to find the object
// - Open a handle to the object and check the status
// - Get a pointer to the object
// - Free the handle
//
    RtlInitUnicodeString(&UniStrPhysMem,  L"\\Device\\PhysicalMemory");
    InitializeObjectAttributes(&ObjAttrs, &UniStrPhysMem, OBJ_CASE_INSENSITIVE, 
			                   (HANDLE)NULL,(PSECURITY_DESCRIPTOR)NULL);

    NtStatus = ZwOpenSection(&hPhysMemory, SECTION_ALL_ACCESS, &ObjAttrs);
    if (!NT_SUCCESS(NtStatus))
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "Mad_MapSysAddr2UsrAddr:ZwOpenSection returned...0x%X\n", NtStatus);
        return NtStatus;
        }

    NtStatus = ObReferenceObjectByHandle(hPhysMemory, SECTION_ALL_ACCESS,
                                         (POBJECT_TYPE)NULL, KernelMode,
                                         &pPhysMemSexn, (POBJECT_HANDLE_INFORMATION)NULL);
    if (!NT_SUCCESS(NtStatus))
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "Mad_MapSysAddr2UsrAddr:ObReferenceObjectByHandle failed...0x%X\n", NtStatus);
        goto close_handle;
        }

// Initialize the physical addresses that will be translated
//
    liPhysAddrBase = liPhysAddr;
    liPhysAddrEnd  = liPhysAddr; 
    liPhysAddrEnd.LowPart += (ULONG)Len2Map;

// Calculate the length of the memory to be mapped
//
    //MapdLen = RtlLargeIntegerSubtract(liPhysAddrEnd, liPhysAddrBase);
    MapdLen.LowPart = liPhysAddrEnd.LowPart - liPhysAddrBase.LowPart;

// If the mappedlength is zero, somthing very weird happened in the HAL
// since the Length was checked against zero.
//
    if (MapdLen.LowPart == 0)
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "Mad_MapSysAddr2UsrAddr...MapdLen.LowPart == 0\n");
        NtStatus = STATUS_UNSUCCESSFUL;
        goto close_handle;
        }

    CommitSize = (size_t)0; //MapdLen.LowPart;
	ViewSize   = (size_t)Len2Map;

// initialize view base that will receive the physical mapped
// address after the MapViewOfSection call.
//
    liViewBase = liPhysAddrBase;

// Let ZwMapViewOfSection pick an address
//
    VirtAddr = NULL;

// Map the section
//
    NtStatus = ZwMapViewOfSection(hPhysMemory,
		                          /*(HANDLE)-1*/ZwCurrentProcess(), //The parent process for this thread  
                                  (PVOID *)&VirtAddr, 
                                  0L, CommitSize, &liViewBase,
                                  (PSIZE_T)&ViewSize, ViewUnmap,
                                  0, (PAGE_READWRITE|PAGE_NOCACHE));
    if (!NT_SUCCESS(NtStatus))
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "Mad_MapSysAddr2UsrAddr:ZwMapViewOfSection failed...NTSTATUS=0x%X, liVuBase=0x%X:%X, MapdLen=%d\n",
					NtStatus, liPhysAddrBase.HighPart, liPhysAddrBase.LowPart, Len2Map);
        goto close_handle;
        }

// Mapping the section above rounded the physical address down to the
// nearest 64 K boundary. Now return a virtual address that sits where
// we want by adding in the offset from the beginning of the section.
//
    *ppMapdMemUsr =
	(PVOID)(VirtAddr + (ULONG)liPhysAddrBase.LowPart - (ULONG)liViewBase.LowPart);

    //*ppMapdMemUsr = (PVOID)VirtAddr;          

close_handle:
    ZwClose(hPhysMemory);

    return NtStatus;
}

/************************************************************************//**
 * Mad_UnmapUsrAddr 
 *
 * DESCRIPTION:
 *    This function unmaps a user mode virtual address from a process.
 *    
 * PARAMETERS: 
 *     @param[in]  pMapdMemUsr user mode pointer to its mapped buffer
 *     
 * RETURNS:
 *    @return      NtStatus    indicates success or reason for the failure
 * 
 ***************************************************************************/
NTSTATUS Mad_UnmapUsrAddr(IN PVOID pMapdMemUsr)

{
    NTSTATUS NtStatus = ZwUnmapViewOfSection(ZwCurrentProcess(), pMapdMemUsr);
    if (!NT_SUCCESS(NtStatus))
	    {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
		            "Mad_UnmapUsrAddr:ZwUnmapViewOfSection failed...NTSTATUS = 0x%X, UserAddr=%p\n",
                    NtStatus, pMapdMemUsr);
	    }

    return NtStatus;
}


/************************************************************************//**
 * MadDevAnalyzeReqType 
 *
 * DESCRIPTION:
 *    This function determines what type of I/O is completed based on
 *    device registers. In our prototype this will indicate that one request
 *    has completed - as if we have 1 request active for any I-O type.
 *    In reality we have only one I-O request active of any type.
 *    
 * PARAMETERS: 
 *     @param[in]  hQueue      handle to our I/O queue for this device.
 *     @param[in]  hRequest    handle to this I/O request
 *     @param[in]  hDevice     handle to our device 
 *     @param[in]  pMadRegs    pointer to the device registers
 *     
 * RETURNS:
 *    @return      DevReqType  enumerated type of I/O determined
 * 
 ***************************************************************************/
MADDEV_IO_TYPE MadDevAnalyzeReqType(PMADREGS pMadRegs)

{
MADDEV_IO_TYPE  DevReqType = eNull_IO; 
ULONG           IntIdReg   = pMadRegs->IntID;
ULONG           ControlReg = pMadRegs->Control;
BOOLEAN         bInput     = ((IntIdReg & MAD_INT_INPUT_MASK) != 0);
BOOLEAN         bOutput    = ((IntIdReg & MAD_INT_OUTPUT_MASK) != 0);

    //BRKPNT;
    IntIdReg &= ~MAD_INT_STATUS_ALERT_BIT;
    if (bInput)
        {
        switch (IntIdReg)
            {
            case MAD_INT_BUFRD_INPUT_BIT:
                if ((ControlReg & MAD_CONTROL_CACHE_XFER_BIT) != 0)
                    DevReqType = eCachedRead;
                else
                    DevReqType = eBufrdRead;
                break;

            case MAD_INT_DMA_INPUT_BIT:
                if ((ControlReg & MAD_CONTROL_CHAINED_DMA_BIT) != 0)
                    DevReqType = eSgDmaRead;
                else
                    DevReqType = eDmaRead;
                break;

            case MAD_INT_ALIGN_INPUT_BIT:
                DevReqType = eReadAlign;
                break;

            default:
                TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
					        "MadDevAnalyzeReqType...multiple input id bits set: IntIdReg=0x%X\n", 
                            IntIdReg);
                DevReqType = eMltplIO;
            } // end switch
        }

    if (bOutput)
        {
        switch (IntIdReg)
            {
            case MAD_INT_BUFRD_OUTPUT_BIT:
                if ((ControlReg & MAD_CONTROL_CACHE_XFER_BIT) != 0)
                    DevReqType = eCachedWrite;
                else
                    DevReqType = eBufrdWrite;
                break;

            case MAD_INT_DMA_OUTPUT_BIT:
                if ((ControlReg & MAD_CONTROL_CHAINED_DMA_BIT) != 0)
                    DevReqType = eSgDmaWrite;
                else
                    DevReqType = eDmaWrite;
                break;

            case MAD_INT_ALIGN_OUTPUT_BIT:
                DevReqType = eWriteAlign;
                break;

            default:
                TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
					        "MadDevAnalyzeReqType...multiple output id bits set: IntIdReg=0x%X\n", 
                            IntIdReg);
                DevReqType = eMltplIO;
            } // end switch
        }

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
		        "MadDevAnalyzeReqType...DevReqType=%d\n", DevReqType);

	return DevReqType;
}


//* Generate an Error Log Entry from passed paramters
//*
void MadWriteEventLogMesg(NTSTATUS NtStatMC, ULONG NumStrings, ULONG LenParms, PWSTR pwsInfoStr)

{
static LARGE_INTEGER liZERO = {0, 0};
NTSTATUS NtStatFinl = STATUS_SUCCESS;
PIO_ERROR_LOG_PACKET pErrLogObj;
PWSTR pwsStrParms;

    if (gpDrivrObj == NULL)
        return;

    pErrLogObj = (PIO_ERROR_LOG_PACKET)IoAllocateErrorLogEntry(gpDrivrObj,
                                                               ERROR_LOG_MAXIMUM_SIZE);
    if (pErrLogObj == NULL)
        return;

	//A special case use of status as 4-byte dump data
	//
	if (NumStrings == 1)
		if (LenParms == sizeof(NTSTATUS))
			if (pwsInfoStr != NULL)
			    {
		        NtStatFinl = *(NTSTATUS *)pwsInfoStr;
				RtlMoveMemory(&pErrLogObj->DumpData, pwsInfoStr, LenParms);
     			}

    pErrLogObj->MajorFunctionCode = 0x00; 
    pErrLogObj->RetryCount        = 0; 
	pErrLogObj->DumpDataSize      = (USHORT)LenParms; 
    pErrLogObj->NumberOfStrings   = (USHORT)NumStrings;
    pErrLogObj->StringOffset      = sizeof(IO_ERROR_LOG_PACKET); //+ ulLenParms; 
    pErrLogObj->EventCategory     = 0;
    pErrLogObj->ErrorCode         = NtStatMC; 
    pErrLogObj->UniqueErrorValue  = 0; 
	pErrLogObj->FinalStatus       = NtStatFinl;
    pErrLogObj->SequenceNumber    = 0L;
    pErrLogObj->IoControlCode     = 0L;
    pErrLogObj->DeviceOffset      = liZERO;
    if (LenParms > 0)
        {
         pwsStrParms = (PWSTR)((ULONG_PTR)pErrLogObj + pErrLogObj->StringOffset);
        RtlMoveMemory(pwsStrParms, pwsInfoStr, LenParms);
        }

	//And finally
    IoWriteErrorLogEntry(pErrLogObj); 

    return;
}
