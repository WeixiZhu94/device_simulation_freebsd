/********1*********2*********3*********4*********5**********6*********7*********/
/*                                                                             */
/*  PRODUCT      : MAD Device Simulation Framework                             */
/*  COPYRIGHT    : (c) 2022 HTF Consulting                                     */
/*                                                                             */
/* This source code is provided by exclusive license for non-commercial use to */
/* XYZ Company                                                                 */
/*                                                                             */
/*******************************************************************************/
/*                                                                             */
/*  Exe file ID  : MadBus.sys                                                  */
/*                                                                             */
/*  Module  NAME : MadBusPdo.cpp                                               */
/*                                                                             */
/*  DESCRIPTION  : PDO functions for the simulator-bus driver                  */
/*                 Derived from WDK-Toaster\bus\pdo.c                          */
/*                                                                             */
/*******************************************************************************/

#include "MadBus.h"
#include "..\Includes\MadUtilFunxns.h"

#ifdef WPP_TRACING
    #include "MadBusEtw.h"
	#include "MadBusPdo.tmh"
#endif

extern BOOLEAN                   gbAffinityOn;
extern ULONG                     gNumAllocDevices;
extern ULONG                     gNumFilters;
extern MADBUS_DEVICE_CONFIG_DATA gMadDevDfltCnfg;  
extern PDO_DEVICE_OIDS           gPdoDevOidsList[];
extern WDFSPINLOCK               ghPdoDevOidsLock;
extern ULONG                     gMadDataXtent;

ULONG BusEnumDebugLevel;

#ifdef ALLOC_PRAGMA
#pragma alloc_text(PAGE, MadBus_CreatePdo)
#pragma alloc_text(PAGE, MadBusEvtDeviceListCreatePdo)
#endif


/************************************************************************//**
 * MadBusEvtChildListIdentificationDescriptionDuplicate
 *
 * DESCRIPTION:
 *    This function is called when the framework needs to make a copy of a 
 *    description.  This happens when a request is made to create a new child
 *    device by calling WdfChildListAddOrUpdateChildDescriptionAsPresent.
 *    If this function is left unspecified, RtlCopyMemory will be used instead.
 *    Memory for the description is managed by the framework.
 *
 *   NOTE:   Callback is invoked with an internal lock held.  So do not call out
 *   to any WDF function which will require this lock
 *   (basically any other WDFCHILDLIST api)initiates a read to the Bob device.
 *    
 * PARAMETERS: 
 *     @param[in]  hDeviceList  Handle to the default WDFCHILDLIST created
 *                              by the framework.
 *     @param[in]  pSrcpIdDesc  Description of the child being created
 *     @param[in]  pDestpIdDesc Created by the framework in nonpaged pool 
 *     
 * RETURNS:
 *    @return      NtStatus    indicates success or reason for the failure
 * 
 ***************************************************************************/
NTSTATUS 
MadBusEvtChildListIdentificationDescriptionDuplicate(WDFCHILDLIST hDeviceList,
                                                     PWDF_CHILD_IDENTIFICATION_DESCRIPTION_HEADER pSrcpIdDesc,
                                                     PWDF_CHILD_IDENTIFICATION_DESCRIPTION_HEADER pDestpIdDesc)
{
PPDO_IDENTIFICATION_DESCRIPTION pSrc, pDest;
size_t safeMultResult;
NTSTATUS NtStatus;
SIZE_T   Len;

    UNREFERENCED_PARAMETER(hDeviceList);

    pSrc = CONTAINING_RECORD(pSrcpIdDesc,
                             PDO_IDENTIFICATION_DESCRIPTION,
                             Header);
    pDest = CONTAINING_RECORD(pDestpIdDesc,
                              PDO_IDENTIFICATION_DESCRIPTION,
                              Header);

    pDest->SerialNo = pSrc->SerialNo;
    pDest->CchHardwareIds = pSrc->CchHardwareIds;
    NtStatus = 
    RtlSizeTMult(pDest->CchHardwareIds, sizeof(WCHAR), &safeMultResult);
    if (!NT_SUCCESS(NtStatus))
        return NtStatus;

    pDest->HardwareIds = 
    (PWCHAR)ExAllocatePoolWithTag(NonPagedPool, safeMultResult, MADBUS_POOL_TAG);

    if (pDest->HardwareIds == NULL) 
        return STATUS_INSUFFICIENT_RESOURCES;

    Len = pDest->CchHardwareIds * sizeof(WCHAR);
    RtlCopyMemory(pDest->HardwareIds, pSrc->HardwareIds, Len);

    return STATUS_SUCCESS;
}


/************************************************************************//**
 * MadBusEvtChildListIdentificationDescriptionCompare
 *
 * DESCRIPTION:
 *    This function is called when the framework needs to compare one 
 *    description with another. Typically this happens whenever a request is
 *     made to add a new child device.  If this function is left unspecified, 
 *    RtlCompareMemory will be used to compare the descriptions.
 *    
 * PARAMETERS: 
 *     @param[in]  hChildList  Handle to the framnework's default WDFCHILDLIST
 *     
 * RETURNS:
 *    @return      BOOLEAN     indicates success or failure
 * 
 ***************************************************************************/
BOOLEAN
MadBusEvtChildListIdentificationDescriptionCompare(WDFCHILDLIST hChildList,
                                                   PWDF_CHILD_IDENTIFICATION_DESCRIPTION_HEADER p1stIdDesc,
                                                   PWDF_CHILD_IDENTIFICATION_DESCRIPTION_HEADER p2ndIdDesc)
{
PPDO_IDENTIFICATION_DESCRIPTION pLHS, pRHS;

    UNREFERENCED_PARAMETER(hChildList);

    pLHS = CONTAINING_RECORD(p1stIdDesc, PDO_IDENTIFICATION_DESCRIPTION, Header);
    pRHS = CONTAINING_RECORD(p2ndIdDesc, PDO_IDENTIFICATION_DESCRIPTION, Header);

    return (pLHS->SerialNo == pRHS->SerialNo) ? TRUE : FALSE;
}


/************************************************************************//**
 * MadBusEvtChildListIdentificationDescriptionCleanup
 *
 * DESCRIPTION:
 *    This function is called to free up any memory resources allocated as
 *    part of the description.  This happens when a child device is unplugged 
 *    or ejected from the bus.
 *   Memory for the description itself will be freed by the framework.
 *    
 * PARAMETERS: 
 *     @param[in]  hDeviceList Handle to the framework's default WDFCHILDLIST
 *     @param[in]  pIdDesc     Description of the child being de-allocated 
 *     
 * RETURNS:
 *    @return      NtStatus    indicates success or reason for the failure
 *    @return      void        nothing returned
 * 
 ***************************************************************************/
VOID
#pragma warning(suppress: 6101)
MadBusEvtChildListIdentificationDescriptionCleanup(WDFCHILDLIST hDeviceList,
                                                   PWDF_CHILD_IDENTIFICATION_DESCRIPTION_HEADER pIdDesc)

{
PPDO_IDENTIFICATION_DESCRIPTION pDesc;

    UNREFERENCED_PARAMETER(hDeviceList);

    pDesc = CONTAINING_RECORD(pIdDesc,
                              PDO_IDENTIFICATION_DESCRIPTION,
                              Header);
    if (pDesc->HardwareIds != NULL) 
        {
        ExFreePool(pDesc->HardwareIds);
        pDesc->HardwareIds = NULL;
        }

    return;
}


/************************************************************************//**
 * MadBusEvtDeviceListCreatePdo

  *
 * DESCRIPTION:
 *    This function is called by the framework in response to Query-Device 
 *    relation when a new PDO for a child device needs to be created.
 *    
 * PARAMETERS: 
 *     @param[in]  hDeviceList Handle to the framework's default WDFCHILDLIST
 *     @param[in]  pIdDesc     Description of the child being de-allocated 
 *     @param[in]  pChildInit  pointer to an opaque structure used in 
 *                             collecting device settings and passed in as a 
 *                             parameter to CreateDevice 
 *     
 * RETURNS:
 *    @return      NtStatus    indicates success or reason for the failure
 * 
 ***************************************************************************/
NTSTATUS MadBusEvtDeviceListCreatePdo(WDFCHILDLIST hDeviceList,
                                      PWDF_CHILD_IDENTIFICATION_DESCRIPTION_HEADER pIDdesc,
                                      PWDFDEVICE_INIT pChildInit)

{
PPDO_IDENTIFICATION_DESCRIPTION pDesc;

    PAGED_CODE();

    pDesc = CONTAINING_RECORD(pIDdesc, PDO_IDENTIFICATION_DESCRIPTION, Header);

    return MadBus_CreatePdo(WdfChildListGetDevice(hDeviceList),
                         pChildInit,
                         pDesc->HardwareIds,
                         pDesc->SerialNo);
}


/************************************************************************//**
 * MadBus_CreatePdo
 *
 * DESCRIPTION:
 *    This function creates and initializes a PDO. 
 *    
 * PARAMETERS: 
 *     @param[in]  hDevice     handle to our device 
 *     @param[in]  pDeviceInit pointer to a framework device init structure
 *     @param[in]  HardwareIDs pointer the hardware id description
 *     @param[in]  SerialNo    Serial number of the pdo to be created
 *     
 * RETURNS:
 *    @return      NtStatus    indicates success or reason for the failure
 * 
 ***************************************************************************/
NTSTATUS MadBus_CreatePdo(__in WDFDEVICE       hDevice,
                          __in PWDFDEVICE_INIT pDeviceInit,
                          __in PWCHAR          HardwareIDs,
                          __in ULONG           SerialNo)

{
static UCHAR PnpIrpMinrFunxns[] = {IRP_MN_START_DEVICE, IRP_MN_READ_CONFIG, 0xFF}; //IRP_MJ_PNP
static WCHAR wcDigits[] = MAD_OBJECTNAME_UNITNUM_WSTR;
//
NTSTATUS                      NtStatus = STATUS_SUCCESS;
PFDO_DEVICE_DATA              pFdoData = NULL;
PPDO_DEVICE_DATA              pPdoData = NULL;
WDFDEVICE                     hChild = NULL;
WDF_QUERY_INTERFACE_CONFIG    qiConfig;
WDF_OBJECT_ATTRIBUTES         pdoAttributes;
WDF_PNPPOWER_EVENT_CALLBACKS  PnpPowerCallbacks;
WDF_DEVICE_PNP_CAPABILITIES   pnpCaps;
WDF_DEVICE_POWER_CAPABILITIES powerCaps;
MADDEVICE_INTERFACE_STANDARD  MadDeviceInterface;
//DECLARE_UNICODE_STRING_SIZE(compatID, (sizeof(*HardwareIDs) / sizeof(WCHAR))); // = Hardware ID - no meaningful compatible ID
DECLARE_CONST_UNICODE_STRING(deviceLocation, L"MadDevice Bus 0");
DECLARE_UNICODE_STRING_SIZE(deviceDescription, MAX_INSTANCE_ID_LEN);
DECLARE_UNICODE_STRING_SIZE(instanceID, MAX_INSTANCE_ID_LEN);
DECLARE_UNICODE_STRING_SIZE(deviceID, MAX_INSTANCE_ID_LEN);
//WDF_PDO_EVENT_CALLBACKS       PdoEventCallbacks;
SIZE_T  TotlDevSize = MAD_DEVICE_MEM_SIZE_NODATA + gMadDataXtent; //The registry adjusted data extent
WCHAR                                 wcNtMadDeviceName[] = MADBUS_NT_DEVICE_NAME_WSTR;
UNICODE_STRING                        NtDeviceName;

    PAGED_CODE();

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,"Entering MadBus_CreatePdo\n");

    // Set DeviceType
    //
    WdfDeviceInitSetDeviceType(pDeviceInit, FILE_DEVICE_BUS_EXTENDER);

	//Let's name our device object so we can find it in the object data base
	//Using Sysinternals:WinObj.exe / OSR:DeviceTree.exe
	//
	wcNtMadDeviceName[MADBUS_NT_DEVICE_NAME_UNITID_INDX] = wcDigits[SerialNo];
	RtlInitUnicodeString(&NtDeviceName, wcNtMadDeviceName);
	//When we do this we prevent the device driver from creating an interface_guid for the FDO *!*
	//NtStatus = WdfDeviceInitAssignName(pDeviceInit, &NtDeviceName);
	//
	if (!NT_SUCCESS(NtStatus))
	    {
		TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadBus_CreatePDO:WdfDeviceInitAssignName returned 0x%X; the device object will be unnamed\n",
			        NtStatus);
	    }

    // Provide DeviceID, HardwareIDs, CompatibleIDs and InstanceId
    //
    RtlInitUnicodeString(&deviceID, HardwareIDs);

    NtStatus = WdfPdoInitAssignDeviceID(pDeviceInit, &deviceID);
    if (!NT_SUCCESS(NtStatus)) 
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadBus_CreatePdo:WdfPdoInitAssignDeviceID returned...0x%X\n", NtStatus);

		MadWriteEventLogMesg(MADBUS_CREATE_CHILD_DEVICE_ERROR, 1, sizeof(NTSTATUS), (PWSTR)&NtStatus); //Minimal payload
        return NtStatus;
        }

    // NOTE: same string  is used to initialize hardware id too
    //
    NtStatus = WdfPdoInitAddHardwareID(pDeviceInit, &deviceID);
    if (!NT_SUCCESS(NtStatus))
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadBus_CreatePdo:WdfPdoInitAddHardwareID returned...0x%X\n", NtStatus);

		MadWriteEventLogMesg(MADBUS_CREATE_CHILD_DEVICE_ERROR, 1, sizeof(NTSTATUS), (PWSTR)&NtStatus); //Minimal payload
        return NtStatus;
        } 

	//RtlInitUnicodeString(&compatID, HardwareIDs); // compatID=HardwareID - no meaningful compatible ID
    //NtStatus = WdfPdoInitAddCompatibleID(pDeviceInit, &compatID );
    //if (!NT_SUCCESS(NtStatus))
    //   return NtStatus;

    NtStatus =  RtlUnicodeStringPrintf(&instanceID, L"%d", SerialNo);
    if (!NT_SUCCESS(NtStatus)) 
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadBus_CreatePdo:RtlUnicodeStringPrintf returned...0x%X\n", NtStatus);

		MadWriteEventLogMesg(MADBUS_CREATE_CHILD_DEVICE_ERROR, 1, sizeof(NTSTATUS), (PWSTR)&NtStatus); //Minimal payload
        return NtStatus;
        } 

    NtStatus = WdfPdoInitAssignInstanceID(pDeviceInit, &instanceID);
    if (!NT_SUCCESS(NtStatus)) 
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadBus_CreatePdo:WdfPdoInitAssignInstanceID returned...x%X\n", NtStatus);

		MadWriteEventLogMesg(MADBUS_CREATE_CHILD_DEVICE_ERROR, 1, sizeof(NTSTATUS), (PWSTR)&NtStatus); //Minimal payload
        return NtStatus;
        } 

    // Provide a description about the device. This text is usually read from the device.
    // In the case of USB device, this text comes from the string descriptor. 
    // This text is displayed momentarily by the PnP manager while it's looking for a matching INF.
    // If it finds one, it uses the Device Description from the INF file or the friendly name created by
    // coinstallers to display in the device manager. 
    // FriendlyName takes precedence over the DeviceDesc from the INF file.
    //
    NtStatus = RtlUnicodeStringPrintf(&deviceDescription, L"HTF_Consulting_MadDevice%d", SerialNo);
    if (!NT_SUCCESS(NtStatus)) 
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadBus_CreatePdo:RtlUnicodeStringPrintf returned...0x%X\n", NtStatus);

		MadWriteEventLogMesg(MADBUS_CREATE_CHILD_DEVICE_ERROR, 1, sizeof(NTSTATUS), (PWSTR)&NtStatus); //Minimal payload
        return NtStatus;
        } 

    // We can call WdfPdoInitAddDeviceText multiple times, adding device text for multiple locales. 
    // When the system displays the text, it chooses the text that matches the current locale, if available.
    // Otherwise it will use the string for the default locale.
    // The driver can specify the driver's default locale by calling WdfPdoInitSetDefaultLocale.
    //
    NtStatus = 
	WdfPdoInitAddDeviceText(pDeviceInit, &deviceDescription, &deviceLocation, MAD_DFLT_LOCALE_ID);
    if (!NT_SUCCESS(NtStatus)) 
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadBus_CreatePdo:WdfPdoInitAddDeviceText returned...0x%X - continuing\n", NtStatus);
        //return NtStatus;
        } 
    WdfPdoInitSetDefaultLocale(pDeviceInit, MAD_DFLT_LOCALE_ID);

    // Register PNP & power callbacks.
    // 1st - initialize the PnpPowerCallbacks structure.  
    //
    WDF_PNPPOWER_EVENT_CALLBACKS_INIT(&PnpPowerCallbacks);
    PnpPowerCallbacks.EvtDevicePrepareHardware   = MadBusPdoEvtPrepareHardware;
    //PnpPowerCallbacks.EvtDeviceReleaseHardware   = MadEvtReleaseHardware;
    //PnpPowerCallbacks.EvtDeviceSelfManagedIoInit = MadEvtSelfManagedIoInit;

    // Register Power callbacks.
    // If we don't supply any callbacks, the Framework will take appropriate default actions based on whether
    // pDeviceInit is initialized to be an FDO, a PDO or a filter device object.
    //
    PnpPowerCallbacks.EvtDeviceD0Entry = MadBusPdoEvtD0Entry;
    PnpPowerCallbacks.EvtDeviceD0Exit  = MadBusPdoEvtD0Exit;
    WdfDeviceInitSetPnpPowerEventCallbacks(pDeviceInit, &PnpPowerCallbacks);

	//An error here is not a show-stopper (because we have no internal ioctls to support)
	NtStatus = 
	WdfDeviceInitAssignWdmIrpPreprocessCallback(pDeviceInit, MadBusPdoEvtWdmIrpPreprocess,
                                                IRP_MJ_INTERNAL_DEVICE_CONTROL, NULL, 0); //No list - we'll get everything, but we have no ioctls defined
	UNREFERENCED_PARAMETER(NtStatus); //Make OACR happy

	//But we gotta have this
	NtStatus = WdfDeviceInitAssignWdmIrpPreprocessCallback(pDeviceInit,
                                                           MadBusPdoEvtWdmIrpPreprocess,
                                                           IRP_MJ_PNP,       //UCHAR  MajorFunction,
                                                           PnpIrpMinrFunxns, //List of minor funxn codes
                                                           2);               //ULONG NumMinorFunctions
    if (!NT_SUCCESS(NtStatus)) //This is a show-stopper
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadBus_CreatePdo:WdfDeviceInitAssignWdmIrpPreprocessCallback returned...0x%X\n", NtStatus);

		MadWriteEventLogMesg(MADBUS_CREATE_CHILD_DEVICE_ERROR, 1, sizeof(NTSTATUS), (PWSTR)&NtStatus); //Minimal payload
        return NtStatus;
        } 

    // Initialize the attributes to specify the size of PDO device extension.
    // All the state information private to the PDO will be tracked here.
    //
    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&pdoAttributes, PDO_DEVICE_DATA);

    NtStatus = WdfDeviceCreate(&pDeviceInit, &pdoAttributes, &hChild);
    if (!NT_SUCCESS(NtStatus)) 
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadBus_CreatePdo:WdfDeviceCreate returned...0x%X\n", NtStatus);

		MadWriteEventLogMesg(MADBUS_CREATE_CHILD_DEVICE_ERROR, 1, sizeof(NTSTATUS), (PWSTR)&NtStatus); //Minimal payload
        return NtStatus;
        } 

    // Get the device contexts.
    //
    pFdoData = MadBusFdoGetData(hDevice);
    pPdoData = MadBusPdoGetData(hChild);
	//
    pPdoData->SerialNo = SerialNo;
	pPdoData->hDevice  = hChild;
	pPdoData->pFdoData = pFdoData;

	//Record Device Object IDs for searching/retrieving  
    //
	WdfSpinLockAcquire(ghPdoDevOidsLock);
	gPdoDevOidsList[SerialNo].pPhysDevObj = WdfDeviceWdmGetDeviceObject(hChild);
	gPdoDevOidsList[SerialNo].hPhysDevice = hChild;
	WdfSpinLockRelease(ghPdoDevOidsLock);

    //Configuration-space data. 1st assign default parameters
    RtlCopyMemory(&pPdoData->BusPdoCnfgData, &pFdoData->DfltCnfgData, MADBUS_DEV_CNFG_SIZE);

    //Override w/ device-specific data (addresses etc.) 
    //
	ULONG DevOffset = (ULONG)((SerialNo - 1) * TotlDevSize);
    ULONG DeviceBase = pFdoData->liDevicesBase.LowPart + DevOffset; 
    pPdoData->BusPdoCnfgData.LegacyPci.u.type0.BaseAddresses[0] = DeviceBase;
    pPdoData->BusPdoCnfgData.LegacyPci.u.type0.BaseAddresses[1] = DeviceBase + MAD_MAPD_READ_OFFSET;
    pPdoData->BusPdoCnfgData.LegacyPci.u.type0.BaseAddresses[2] = DeviceBase + MAD_MAPD_WRITE_OFFSET;
    pPdoData->BusPdoCnfgData.LegacyPci.u.type0.BaseAddresses[3] = DeviceBase + MAD_DEVICE_DATA_OFFSET;
 
    //Vendor-specific data
    //Leave device range physical addrs. alone after config registry read
	//
    pPdoData->BusPdoCnfgData.VndrSpecData.BusSlotNum      = SerialNo;
    pPdoData->BusPdoCnfgData.VndrSpecData.IntMode         = MADDEV_INT_MODE;
    pPdoData->BusPdoCnfgData.VndrSpecData.DevPowerState   = PowerDeviceD0; //Starting powered up
    pPdoData->BusPdoCnfgData.VndrSpecData.pMadSimIntParms = &pPdoData->MadSimIntParms; //So that the device driver can exchange parms in simulation_mode

    #ifdef KMDF_WONT_CREATE_DMA_ENABLER //////////////////////////////////////////////////////////////
	pPdoData->MadSimDmaFunxns.pDmaEnablerCreate     = (PFN_DMA_ENABLER_CREATE)&MadSimDmaEnablerCreate;
	pPdoData->MadSimDmaFunxns.pDmaSetMaxSgElems     = (PFN_DMA_ENABLER_SET_MAX_SG_ELEMS)&MadSimDmaEnablerSetMaximumScatterGatherElements;
	pPdoData->MadSimDmaFunxns.pDmaXaxnCreate        = (PFN_DMA_TRANSACTION_CREATE)&MadSimDmaTransactionCreate;
	pPdoData->MadSimDmaFunxns.pDmaXaxnInitFromReq   = (PFN_DMA_TRANSACTION_INIT_FROM_REQ)&MadSimDmaTransactionInitializeUsingRequest;
	pPdoData->MadSimDmaFunxns.pDmaXaxnExecute       = (PFN_DMA_TRANSACTION_EXECUTE)&MadSimDmaTransactionExecute;
	pPdoData->MadSimDmaFunxns.pDmaXaxnGetRequest    = (PFN_DMA_TRANSACTION_GET_REQUEST)&MadSimDmaTransactionGetRequest;
	pPdoData->MadSimDmaFunxns.pDmaXaxnGetBytesXferd = (PFN_DMA_TRANSACTION_GET_BYTES_XFERD)&MadSimDmaTransactionGetBytesTransferred;
	pPdoData->MadSimDmaFunxns.pDmaXaxnCompleted     = (PFN_DMA_TRANSACTION_DMA_COMPLETED)&MadSimDmaTransactionDmaCompleted;
	//pPdoData->MadSimDmaFunxns.pDmaXaxnGetDevice     = (PFN_DMA_TRANSACTION_GET_DEVICE)&MadSimDmaTransactionGetDevice;
	//
	pPdoData->BusPdoCnfgData.VndrSpecData.pMadSimDmaFunxns = &pPdoData->MadSimDmaFunxns;
    #endif //KMDF_WONT_CREATE_DMA_ENABLER  ///////////////////////////////////////////////////////////

	//Copy the vendor-specific data into PCI.DeviceSpecific - just so it's available either place
    RtlCopyMemory(pPdoData->BusPdoCnfgData.LegacyPci.DeviceSpecific, 
                  &pPdoData->BusPdoCnfgData.VndrSpecData, VENDOR_SPEC_DATA_SIZE);
  
    //Assign CM_RESOURCE_LIST parameters to be passed up to the functional (device) driver
    //
    pPdoData->Irql                   = pFdoData->OurIRQL; 
    pPdoData->IDTindx                = pFdoData->OurVector; 

	//Processor affinity for this device is constrained to one specific processor = Serial# ... or no constraint
    pPdoData->IntAffinity            = gbAffinityOn ? (0x01<<SerialNo) : 0xFFFFFFFF; 
	//
    pPdoData->liDevBase.LowPart      = pPdoData->BusPdoCnfgData.LegacyPci.u.type0.BaseAddresses[0];
    pPdoData->liDevBase.HighPart     = 0L;
    pPdoData->liDevPioRead.LowPart   = pPdoData->BusPdoCnfgData.LegacyPci.u.type0.BaseAddresses[1];
    pPdoData->liDevPioRead.HighPart  = 0L;
    pPdoData->liDevPioWrite.LowPart  = pPdoData->BusPdoCnfgData.LegacyPci.u.type0.BaseAddresses[2];
    pPdoData->liDevPioWrite.HighPart = 0L;
 
    //Assign virt addrs for the device
    //
    pPdoData->pMadRegs = 
    (PMADREGS)MmMapIoSpace(pPdoData->liDevBase, MAD_REGISTER_BLOCK_SIZE, MAD_MEM_CACHE_TYPE);
	//
	pPdoData->pPioRead = 
    MmMapIoSpace(pPdoData->liDevPioRead, MAD_MAPD_READ_SIZE, MAD_MEM_CACHE_TYPE);
	pPdoData->pReadCache = pPdoData->pPioRead;
	//
	pPdoData->pPioWrite =
    MmMapIoSpace(pPdoData->liDevPioWrite, MAD_MAPD_WRITE_SIZE, MAD_MEM_CACHE_TYPE);
	pPdoData->pWriteCache = pPdoData->pPioWrite;
	//
	pPdoData->liDeviceData.LowPart  =
	pPdoData->BusPdoCnfgData.LegacyPci.u.type0.BaseAddresses[3];
    pPdoData->liDeviceData.HighPart = 0L;
    pPdoData->pDeviceData = 
	MmMapIoSpace(pPdoData->liDeviceData, gMadDataXtent, MAD_MEM_CACHE_TYPE);

    //Initialize device data
	RtlFillMemory(pPdoData->pDeviceData, gMadDataXtent, 0xFF);

	//TBD: Anything saved to disk to be retrieved maybe ?
	//Let the user do it in the UI

    // Set some properties for the child device.
    //
    WDF_DEVICE_PNP_CAPABILITIES_INIT(&pnpCaps);
    pnpCaps.Removable         = WdfTrue;
    pnpCaps.EjectSupported    = WdfTrue;
    pnpCaps.SurpriseRemovalOK = WdfTrue;
    pnpCaps.Address           = SerialNo;
    pnpCaps.UINumber          = SerialNo;
    WdfDeviceSetPnpCapabilities(hChild, &pnpCaps);

    WDF_DEVICE_POWER_CAPABILITIES_INIT(&powerCaps);
    powerCaps.DeviceD1                          = WdfTrue;
    powerCaps.WakeFromD1                        = WdfTrue;
    powerCaps.DeviceWake                        = PowerDeviceD1;
    powerCaps.DeviceState[PowerSystemWorking]   = PowerDeviceD1;
    powerCaps.DeviceState[PowerSystemSleeping1] = PowerDeviceD1;
    powerCaps.DeviceState[PowerSystemSleeping2] = PowerDeviceD2;
    powerCaps.DeviceState[PowerSystemSleeping3] = PowerDeviceD2;
    powerCaps.DeviceState[PowerSystemHibernate] = PowerDeviceD3;
    powerCaps.DeviceState[PowerSystemShutdown]  = PowerDeviceD3;
    WdfDeviceSetPowerCapabilities(hChild, &powerCaps);

    // Create a custom interface so that other drivers can
    // query (IRP_MN_QUERY_INTERFACE) and use our callbacks directly.
    //
    RtlZeroMemory(&MadDeviceInterface, sizeof(MadDeviceInterface));

    MadDeviceInterface.InterfaceHeader.Size    = sizeof(MadDeviceInterface);
    MadDeviceInterface.InterfaceHeader.Version = 1;
    MadDeviceInterface.InterfaceHeader.Context = (PVOID)hChild;

    // Let the framework handle reference counting.
    //
    MadDeviceInterface.InterfaceHeader.InterfaceReference   = WdfDeviceInterfaceReferenceNoOp;
    MadDeviceInterface.InterfaceHeader.InterfaceDereference = WdfDeviceInterfaceDereferenceNoOp;

    MadDeviceInterface.GetPowerLevel  = (PMADDEVICE_GET_POWER_LEVEL)MadBus_GetPowerLevel;
    MadDeviceInterface.SetPowerLevel  = (PMADDEVICE_SET_POWER_LEVEL)MadBus_SetPowerLevel;
    MadDeviceInterface.IsSafetyLockEnabled = (PMADDEVICE_IS_CHILD_PROTECTED)MadBus_IsSafetyLockEnabled;

    WDF_QUERY_INTERFACE_CONFIG_INIT(&qiConfig,
                                    (PINTERFACE)&MadDeviceInterface,
                                    &GUID_MADDEVICE_INTERFACE_STANDARD,
                                    NULL);

    // If we have multiple interfaces, we can call WdfDeviceAddQueryInterface N times to add add'l interfaces.
    //
    NtStatus = WdfDeviceAddQueryInterface(hChild, &qiConfig);
    if (!NT_SUCCESS(NtStatus)) 
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadBus_CreatePdo:WdfDeviceAddQueryInterface returned...0x%X\n", NtStatus);

		MadWriteEventLogMesg(MADBUS_CREATE_CHILD_DEVICE_ERROR, 1, sizeof(NTSTATUS), (PWSTR)&NtStatus); //Minimal payload
        return NtStatus;
        }

    //Initialize our interrupt thread synchronization events 
	//
    KeInitializeEvent(&pPdoData->evIntThreadExit, NotificationEvent, FALSE);
	pPdoData->MadSimIntParms.pEvIntThreadExit = &pPdoData->evIntThreadExit;
    KeInitializeEvent(&pPdoData->MadSimIntParms.evDevPowerUp, NotificationEvent, FALSE);
    KeInitializeEvent(&pPdoData->MadSimIntParms.evDevPowerDown, NotificationEvent, FALSE);
	
	//Spawn the device interrupt thread
    //
    NtStatus = 
	PsCreateSystemThread(&pPdoData->hDevIntThread, (SYNCHRONIZE | GENERIC_EXECUTE),
                         NULL, NULL, NULL, MadPdoIntThread, pPdoData);
    if (!NT_SUCCESS(NtStatus)) 
        {
        TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadBus_CreatePdo:PsCreateSystemThread returned...0x%X\n", NtStatus);

		MadWriteEventLogMesg(MADBUS_CREATE_CHILD_DEVICE_ERROR, 1, sizeof(NTSTATUS), (PWSTR)&NtStatus); //Minimal payload
        return NtStatus;
        }

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO, "MadBus_CreatePdo...normal exit\n");

    return NtStatus;
}
 

/************************************************************************//**
 * MadBusPdoEvtPrepareHardware
 *
 * DESCRIPTION:
 *    This event callback function performs operations that are necessary to
 *    make the driver's device operational. The framework calls the driver's 
 *    EvtDevicePrepareHardware callback when the PnP manager sends an
 *    IRP_MN_START_DEVICE request to the driver stack.
 *
 *   Specifically, most drivers will use this callback to map resources.  USB
 *   drivers may use it to get device descriptors, config descriptors and to
 *   select configs.
 *
 *   Some drivers may choose to download firmware to a device in this callback,
 *   but that is usually only a good choice if the device firmware won't be
 *   destroyed by a D0 to D3 transition.  If firmware will be gone after D3,
 *   then firmware downloads should be done in EvtDeviceD0Entry, not here.
 *    
 * PARAMETERS: 
 *     @param[in]  hDevice     handle to our device 
 *     @param[in]  hResrcsRaw  handle to a collection of framework resource
 *                             objects.  This collection identifies the raw
 *                             (bus-relative) hardware resources that have been
 *                             assigned to the device. 
 *     @param[in] hResrcsXlatd  handle to a collection of framework resource
 *                              objects.  This collection identifies the 
 *                              translated (system-physical) hardware resources 
 *                              that have been assigned to the device.
 *                              The resources appear from the CPU's point of view.
 *                              Use this list of resources to map I/O space and
 *                              device-accessible memory into virtual address space
 *     
 * RETURNS:
 *    @return      NtStatus    indicates success or reason for the failure
 * 
 ***************************************************************************/
NTSTATUS MadBusPdoEvtPrepareHardware(WDFDEVICE      hDevice,
                                     WDFCMRESLIST   hResrcsRaw,
                                     WDFCMRESLIST   hResrcsXlatd)
{
NTSTATUS NtStatus = STATUS_SUCCESS;
PCM_PARTIAL_RESOURCE_DESCRIPTOR pPartlResrcDescRaw   = WdfCmResourceListGetDescriptor(hResrcsRaw, 0);
PCM_PARTIAL_RESOURCE_DESCRIPTOR pPartlResrcDescXlatd = WdfCmResourceListGetDescriptor(hResrcsXlatd, 0);
//LONG ResrcCount = WdfCmResourceListGetCount(hResrcsXlatd);

    UNREFERENCED_PARAMETER(hDevice);
    UNREFERENCED_PARAMETER(pPartlResrcDescXlatd);
    UNREFERENCED_PARAMETER(pPartlResrcDescRaw);
	
	TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO, "MadBusPdoEvtPrepareHardware enter\n");
    
	return NtStatus;
}


/************************************************************************//**
 * MadBusPdoEvtD0Entry
 *
 * DESCRIPTION:
 *    This function is the framework callback called when the pdo goes into
 *    device power-state zero.
 *    
 * PARAMETERS: 
 *     @param[in]  hDevice        handle to our device 
 *     @param[in]  PrevPowerState the power state thedevice is coming from
 *     
 * RETURNS:
 *    @return      NtStatus    indicates success or reason for the failure
 * 
 ***************************************************************************/
NTSTATUS MadBusPdoEvtD0Entry(IN WDFDEVICE hDevice, IN WDF_POWER_DEVICE_STATE PrevPowerState)

{
	UNREFERENCED_PARAMETER(hDevice);
	UNREFERENCED_PARAMETER(PrevPowerState);

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
		        "MadBusPdoEvtD0Entry...coming from PowerState %d\n", PrevPowerState);

    return STATUS_SUCCESS;
}


/************************************************************************//**
 * MadBusPdoEvtD0Exit
 *
 * DESCRIPTION:
 *    This function is the framework callback called when the pdo goes into
 *    a lower power-state.
 *    
 * PARAMETERS: 
 *     @param[in]  hDevice     handle to our device (PDO)
 *     @param[in]  PowerState  power state the pdo is going into 
 *     
 * RETURNS:
 *    @return      NtStatus    indicates success or reason for the failure
 * 
 ***************************************************************************/
NTSTATUS MadBusPdoEvtD0Exit(IN WDFDEVICE hDevice, IN WDF_POWER_DEVICE_STATE PowerState)
{
NTSTATUS  NtStatus = STATUS_SUCCESS;

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
		        "MadBusPdoEvtD0Exit...going to PowerState %d\n", PowerState);

	if (PowerState == WdfPowerDeviceD3Final) //Our device is going to the morgue
	    {
		PPDO_DEVICE_DATA pPdoData   = MadBusPdoGetData(hDevice);
		WDFDEVICE        hParentDev = WdfPdoGetParent(hDevice);
	    NtStatus = MadBus_UnPlugDevice(hParentDev, pPdoData->SerialNo);
	    }

    return NtStatus;
}


/************************************************************************//**
 * MadBus_GetPowerLevel
 *
 * DESCRIPTION:
 *    This function gets the current power level of the MadDevice.
 *    It is a DDI Query interface function
 *    
 * PARAMETERS: 
 *     @param[in]  hChildDev  handle to our device 
 *     @param[in]  Level      pointer to the power level 
 *     
 * RETURNS:
 *    @return      BOOLEAN   indicates success or failure
 * 
 ***************************************************************************/
BOOLEAN MadBus_GetPowerLevel(IN WDFDEVICE hChildDev, OUT PUCHAR Level)

{
    UNREFERENCED_PARAMETER(hChildDev);

    // Validate the context to see if it's really a pointer to PDO's device extension. 
    // You can store some kind of signature in the PDO for this purpose
    //
    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO, "GetPowerLevel\n");

    *Level = 10;

    return TRUE;
}


/************************************************************************//**
 * MadBus_SetPowerLevel
 *
 * DESCRIPTION:
 *    This function sets the current power level of the MadDevice.
 *    It is a DDI Query interface function
 *    
 * PARAMETERS: 
 *     @param[in]  hChildDev  handle to our device 
 *     @param[in]  Level      pointer to the power level 
 *     
 * RETURNS:
 *     @return     BOOLEAN    indicates success or failure
 *
 ***************************************************************************/
BOOLEAN MadBus_SetPowerLevel(IN WDFDEVICE hChildDev, IN UCHAR Level)

{
    UNREFERENCED_PARAMETER(hChildDev);
    UNREFERENCED_PARAMETER(Level);

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO, "SetPowerLevel\n");

    return TRUE;
}


/************************************************************************//**
 * MadBus_IsSafetyLockEnabled
 *
 * DESCRIPTION:
 *    This function checks whether safety lock is enabled 
 *    It is a DDI Query interface function
 *    
 * PARAMETERS: 
 *     @param[in]  hChildDev   handle to our device  
 *     
 * RETURNS:
 *    @return      BOOLEAN     indicates yes/no
 * 
 ***************************************************************************/
BOOLEAN MadBus_IsSafetyLockEnabled(IN WDFDEVICE hChildDev)
{
    UNREFERENCED_PARAMETER(hChildDev);

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,"IsSafetyLockEnabled\n");

    return TRUE;
}


/************************************************************************//**
 * MadBusPdoEvtWdmIrpPreprocess
 *
 * DESCRIPTION:
 *    This function is a callback used for special processing of IRP_MJ_PNP
 *    & IRP_MJ_INTERNAL_DEVICE_CONTROL irps
 *    
 * PARAMETERS: 
 *     @param[in]  hDevice   handle to our device 
 *     @param[in]  pIRP      pointer to the I/o Request Pkt for this request
 *     
 * RETURNS:
 *    @return      NtStatus    indicates success or reason for the failure
 * 
 ***************************************************************************/
NTSTATUS MadBusPdoEvtWdmIrpPreprocess(WDFDEVICE hDevice, PIRP pIRP)
{
PPDO_DEVICE_DATA   pPdoData    = MadBusPdoGetData(hDevice);
PIO_STACK_LOCATION pIoStackLoc = IoGetCurrentIrpStackLocation(pIRP);
UCHAR              MajrFunxn   = pIoStackLoc->MajorFunction;
UCHAR              MinrFunxn   = pIoStackLoc->MinorFunction;
NTSTATUS NtStatus = STATUS_SUCCESS;

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
		        "MadBusPdoEvtWdmIrpPreprocess...SerialNo=%d, MajorFunction=0x%X, MinorFunction=0x%X\n", 
				pPdoData->SerialNo, MajrFunxn, MinrFunxn);

    switch (MajrFunxn)
        {
        case IRP_MJ_PNP:
			switch (MinrFunxn)
                {
			    case IRP_MN_START_DEVICE:
                    MadBusPdo_PlugCmResrcsIntoFdoStackLoc(pPdoData, pIRP, pIoStackLoc); 
                    break;

				case IRP_MN_READ_CONFIG:
                    RtlCopyMemory(pIoStackLoc->Parameters.ReadWriteConfig.Buffer, 
                                  &pPdoData->BusPdoCnfgData, sizeof(MADBUS_DEVICE_CONFIG_DATA)); 
					//ASSERT(pPdoData->pIntThreadObj != NULL); //Verify that we have the event object for the thread
                    break;
				default:
					GENERIC_SWITCH_DEFAULTCASE_ASSERT;
			    }
			break;

        case IRP_MJ_INTERNAL_DEVICE_CONTROL: //This ioctl is common from other kernel-mode drivers
			                                 //but we currently have no ioctls defined so we fall through
        default:
			GENERIC_SWITCH_DEFAULTCASE_ASSERT;
        };

	pIRP->IoStatus.Status = STATUS_SUCCESS; //Necessary because D-V forces the client driver to init this status to STATUS_NOT_SUPPORTED (0xC00000BB)
    IoSkipCurrentIrpStackLocation(pIRP);
    NtStatus = WdfDeviceWdmDispatchPreprocessedIrp(hDevice, pIRP);

    return NtStatus;
}


/************************************************************************//**
 * MadBusPdo_PlugCmResrcsIntoFdoStackLoc
 *
 * DESCRIPTION:
 *    This function plugs the device config-mngt parameters into the 
 *    functional (device) driver's IoStack location in the start-device irp so
 *    that the device driver can retrieve them in its PrepareHardware callback.
 *    This function replaces what Pnp-Mngr can't/won't do for us.
 *    
 * PARAMETERS: 
 *     @param[in]  pPdoData    pointer to the framework device extension.
 *     @param[in]  pIRP        pointer to the request IRP
 *     @param[in]  pIoStackLoc pointer to the Io-Stack location for this IRP 
 *     
 * RETURNS:
 *    @return      void        nothing returned
 * 
 ***************************************************************************/
void MadBusPdo_PlugCmResrcsIntoFdoStackLoc(PPDO_DEVICE_DATA pPdoData, PIRP pIRP, IN PIO_STACK_LOCATION pIoStackLoc) 

{
register ULONG j;
PCM_RESOURCE_LIST pResrcList      = (PCM_RESOURCE_LIST)&pPdoData->ResrcList;
PCM_RESOURCE_LIST pResrcListXlatd = (PCM_RESOURCE_LIST)&pPdoData->ResrcListXlatd;
PCM_PARTIAL_RESOURCE_DESCRIPTOR pPartlResrcDesc =
                                &(pResrcList->List[0].PartialResourceList.PartialDescriptors[0]);
PCM_PARTIAL_RESOURCE_DESCRIPTOR pPartlResrcDescXlatd =
                                &(pResrcListXlatd->List[0].PartialResourceList.PartialDescriptors[0]);

//*** Establish a pointer to upper (previous) stack location (Functional Driver)
//* 
PIO_STACK_LOCATION pFdoStackLoc; 
PIO_STACK_LOCATION pTempStackLoc = pIoStackLoc; 

    for (j = 0; j <= gNumFilters; j++) //Step up the iostack 1+NumFilters times
        pTempStackLoc = GET_PREV_IOSTACK_LOCATION(pTempStackLoc); 
    pFdoStackLoc = pTempStackLoc;

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
		        "MadBusPdo_PlugCmResrcsIntoFdoStackLoc...SerialNo=%d, pIRP,pIoStackLoc,PrevStackLoc = %p,%p,%p\n",
                pPdoData->SerialNo, pIRP, pIoStackLoc, pFdoStackLoc);

    pResrcList->Count      = 1; //Unless it's a multi-funxn device 
    pResrcListXlatd->Count = 1;
    pResrcList->List[0].PartialResourceList.Count      = MADDEV_TOTL_CM_RESOURCES;
    pResrcListXlatd->List[0].PartialResourceList.Count = MADDEV_TOTL_CM_RESOURCES;

//*** Assign device memory address
//*
    pPartlResrcDesc->Type               = CmResourceTypePort;
    pPartlResrcDescXlatd->Type          = CmResourceTypePort;
    pPartlResrcDescXlatd->u.Port.Length = MAD_REGISTER_BLOCK_SIZE;   
    pPartlResrcDescXlatd->u.Port.Start  = pPdoData->liDevBase;

//*** Point to next paired descriptors
//*
    pPartlResrcDesc++; 
    pPartlResrcDescXlatd++; 

//*** Assign device interrupt parms 
//*
    pPartlResrcDesc->Type                      = CmResourceTypeInterrupt;
    pPartlResrcDescXlatd->Type                 = CmResourceTypeInterrupt;
    pPartlResrcDescXlatd->u.Interrupt.Level    = pPdoData->Irql;   
    pPartlResrcDescXlatd->u.Interrupt.Vector   = pPdoData->IDTindx;  
    pPartlResrcDescXlatd->u.Interrupt.Affinity = pPdoData->IntAffinity;  

//*** Point to next paired descriptors
//*
    pPartlResrcDesc++; 
    pPartlResrcDescXlatd++; 

//*** Assign static (Non-DMA) buffer addrs.
//*** Device read buffer address
//*
    pPartlResrcDesc->Type                 = CmResourceTypeMemory;
    pPartlResrcDescXlatd->Type            = CmResourceTypeMemory;
    pPartlResrcDescXlatd->u.Memory.Length = MAD_MAPD_READ_SIZE;  
    pPartlResrcDescXlatd->u.Memory.Start  = pPdoData->liDevPioRead;

//*** Point to next paired descriptors
//*
    pPartlResrcDesc++; 
    pPartlResrcDescXlatd++; 

//*** Device write buffer address
//*
    pPartlResrcDesc->Type                 = CmResourceTypeMemory;
    pPartlResrcDescXlatd->Type            = CmResourceTypeMemory;
    pPartlResrcDescXlatd->u.Memory.Length = MAD_MAPD_WRITE_SIZE;  
    pPartlResrcDescXlatd->u.Memory.Start  = pPdoData->liDevPioWrite;

//* Update the functional (device) driver's stack location parameters as would PnP Mngr
//* Non-null address values for the resource lists indicate that there is resource information
//*
    pFdoStackLoc->Parameters.StartDevice.AllocatedResources           = pResrcList;
    pFdoStackLoc->Parameters.StartDevice.AllocatedResourcesTranslated = pResrcListXlatd;

    return;
}


WDFDEVICE  MadFindPdoInOidList(PDEVICE_OBJECT pPhysDevObj, PULONG pSerialNo)

{
register ULONG j;

	*pSerialNo = 0;

	for (j = 1; j <= gNumAllocDevices; j++)
		if (pPhysDevObj == gPdoDevOidsList[j].pPhysDevObj)
			break;

	ASSERT(j <= gNumAllocDevices);
	ASSERT(gPdoDevOidsList[j].pPhysDevObj != NULL);
	ASSERT(gPdoDevOidsList[j].pPhysDevObj != (PVOID)-1);

	*pSerialNo = j;

	return gPdoDevOidsList[j].hPhysDevice;
}

#ifdef KMDF_WONT_CREATE_DMA_ENABLER//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//Here we replace all the DMA processing functions which WDF won't provide because the OS isn't providing 
//a DMA Adapter for devices not on PCI. Therefore WDF can't provide a DMA Enabler ... etc.
//
/************************************************************************//**
* MadSimDmaEnablerCreate
*
* DESCRIPTION:
*    This is the simulation mode replacement for WdfDmaEnablerCreate
*    Create a generic object with context to work around no real Dma-Enabler
*   
* PARAMETERS: 
*     @param[in]  hFDO         handle to the parent device 
*     @param[out] phDmaEnabler pointer to the dma enabler handle
*     
* RETURNS:
*    @return      NtStatus    indicates success or reason for the failure
* 
***************************************************************************/
NTSTATUS MadSimDmaEnablerCreate(IN WDFDEVICE hFDO, //This will be the DEVICE driver FDO - not our PDO
	                            IN PWDF_DMA_ENABLER_CONFIG pDmaConfig, 
	                            IN PWDF_OBJECT_ATTRIBUTES pObjAttr, OUT WDFDMAENABLER* phDmaEnabler)

{
PDEVICE_OBJECT    pPhysDevObj = WdfDeviceWdmGetPhysicalDevice(hFDO);  
//
WDF_OBJECT_ATTRIBUTES  ObjAttrs;
NTSTATUS               NtStatus;
WDFDMAENABLER          hDmaEnabler;
ULONG                  SerialNo;

	UNREFERENCED_PARAMETER(pDmaConfig);
	UNREFERENCED_PARAMETER(pObjAttr);

	WdfSpinLockAcquire(ghPdoDevOidsLock);
	WDFDEVICE         hDevPDO = MadFindPdoInOidList(pPhysDevObj, &SerialNo);
	WdfSpinLockRelease(ghPdoDevOidsLock);

	PPDO_DEVICE_DATA  pPdoData = MadBusPdoGetData(hDevPDO);

	TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
		        "MadSimDmaEnablerCreate...SerialNo=%d, hFDO(FDO)=%p\n",
				pPdoData->SerialNo, hFDO);

	WDF_OBJECT_ATTRIBUTES_INIT(&ObjAttrs);
	ObjAttrs.ParentObject = hFDO;
	WDF_OBJECT_ATTRIBUTES_SET_CONTEXT_TYPE(&ObjAttrs, MADSIM_DMA_ENABLER_CONTEXT);

	NtStatus = WdfObjectCreate(&ObjAttrs, (WDFOBJECT *)&hDmaEnabler);
	if (!NT_SUCCESS(NtStatus))
	    {
		TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadSimDmaEnablerCreate:WdfObjectCreate returned 0x%X\n", NtStatus); 
		return NtStatus;
	    }

	PMADSIM_DMA_ENABLER_CONTEXT pEnablerData =
		                        WdfObjectGetTypedContext(hDmaEnabler, MADSIM_DMA_ENABLER_CONTEXT);
	ASSERT(pEnablerData != NULL);
	if (pEnablerData == NULL) //Return something distinctive other than WDF reporting STATUS_UNSUCCESSFUL ...
		return STATUS_NOT_IMPLEMENTED; //We may as well say we can't do this

	//Update the object context for other functions
	pEnablerData->hFDO = hFDO;

	*phDmaEnabler = hDmaEnabler;

	return STATUS_SUCCESS;
}
//
/************************************************************************//**
* MadSimDmaTransactionCreate
*
* DESCRIPTION:
*    This is the simulation mode replacement for WdfDmaTransactionCreate
*    Create a generic object with context to work around no real Dma-Enabler
*    
* PARAMETERS: 
*     @param[in]  hDmaEnabler handle to the parent dma enabler  
*     @param[out] pDmaXaxn    pointer to the dma transaction handle
*     
* RETURNS:
*    @return      NtStatus    indicates success or reason for the failure
* 
***************************************************************************/
NTSTATUS MadSimDmaTransactionCreate(IN WDFDMAENABLER hDmaEnabler,
	                                IN OPTIONAL WDF_OBJECT_ATTRIBUTES *pObjAttrs,
	                                OUT WDFDMATRANSACTION *phDmaXaxn)

{
PMADSIM_DMA_ENABLER_CONTEXT pEnablerData = 
                            WdfObjectGetTypedContext(hDmaEnabler, MADSIM_DMA_ENABLER_CONTEXT);
WDFDEVICE                   hFDO = pEnablerData->hFDO;
PDEVICE_OBJECT              pPhysDevObj = WdfDeviceWdmGetPhysicalDevice(hFDO);
//
WDF_OBJECT_ATTRIBUTES  ObjAttrs;
NTSTATUS               NtStatus;
WDFDMATRANSACTION      hDmaXaxn;
ULONG                  SerialNo;

	UNREFERENCED_PARAMETER(pObjAttrs);

	WdfSpinLockAcquire(ghPdoDevOidsLock);
	WDFDEVICE         hWdfDevPDO = MadFindPdoInOidList(pPhysDevObj, &SerialNo);
	WdfSpinLockRelease(ghPdoDevOidsLock);

	PPDO_DEVICE_DATA  pPdoData = MadBusPdoGetData(hWdfDevPDO);

	TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
		        "MadSimDmaTransactionCreate...SerialNo=%d, hDmaEnabler=%p\n",
				pPdoData->SerialNo, hDmaEnabler);

	WDF_OBJECT_ATTRIBUTES_INIT(&ObjAttrs);
	ObjAttrs.ParentObject = hDmaEnabler;
	WDF_OBJECT_ATTRIBUTES_SET_CONTEXT_TYPE(&ObjAttrs, MADSIM_DMA_TRANSACTION_CONTEXT);

	NtStatus = WdfObjectCreate(&ObjAttrs, (WDFOBJECT *)&hDmaXaxn);
	if (!NT_SUCCESS(NtStatus))
	    {
		TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadSimDmaTransactionCreate:WdfObjectCreate returned 0x%X\n", NtStatus); 
		return NtStatus;
	    }

	PMADSIM_DMA_TRANSACTION_CONTEXT pXaxnData = 
		                            WdfObjectGetTypedContext(hDmaXaxn, MADSIM_DMA_TRANSACTION_CONTEXT);
	if (pXaxnData == NULL) //Return something distinctive other than WDF reporting STATUS_UNSUCCESSFUL ...
		return STATUS_NOT_IMPLEMENTED; //We may as well say we can't do this

	//Update the object context for other functions
	//Everything else in this context will be determined below in XxxDmaTransactionInitializeUsingRequest
	pXaxnData->hFDO = pEnablerData->hFDO;

	*phDmaXaxn = hDmaXaxn;

	return STATUS_SUCCESS;   
}
//
VOID MadSimDmaEnablerSetMaximumScatterGatherElements(IN WDFDMAENABLER hDmaEnabler, IN size_t MaximumFragments)

{
	UNREFERENCED_PARAMETER(hDmaEnabler);
	UNREFERENCED_PARAMETER(MaximumFragments);

	return; //Nothing to do
}
//
/************************************************************************//**
* MadSimDmaTransactionInitializeUsingRequest
*
* DESCRIPTION:
*    This is the simulation mode replacement for 
*    WdfDmaTransactionInitializeUsingRequest
*    The main purpose is to convert the request's MDL to an OS-internal
*    Scatter-Gather list getting ready for DmaTransactionExecute.
*    
* PARAMETERS: 
*     @param[in]  hDmaXaxn            handle to the Dma transaction  
*     @param[in]  hRequest            handle to the parent request   
*     @param[in]  pEvtProgramDmaFunxn pointer to the dma processing function
*                                     in the DEVICE driver
*     @param[in]  Direxn              indicates read or write
*     
* RETURNS:
*    @return      NtStatus    indicates success or reason for the failure
* 
***************************************************************************/
NTSTATUS 
MadSimDmaTransactionInitializeUsingRequest(IN WDFDMATRANSACTION hDmaXaxn, IN WDFREQUEST hRequest,
                                           IN PFN_WDF_PROGRAM_DMA pEvtProgramDmaFunxn, IN WDF_DMA_DIRECTION Direxn)

{
PMADSIM_DMA_TRANSACTION_CONTEXT pXaxnData = 
                                WdfObjectGetTypedContext(hDmaXaxn, MADSIM_DMA_TRANSACTION_CONTEXT);
WDFDEVICE                       hFDO = pXaxnData->hFDO;
PDEVICE_OBJECT                  pPhysDevObj = WdfDeviceWdmGetPhysicalDevice(hFDO);  
//
NTSTATUS         NtStatus = STATUS_SUCCESS; 
ULONG            NumItems = 0;
PMDL             pMDL = NULL;
PMDL             pCurrMdlItem;
PMDL             pNextMdlItem;
PVOID            SysAddr;
PHYSICAL_ADDRESS PhysAddr;
ULONG            SerialNo;

    WdfSpinLockAcquire(ghPdoDevOidsLock);
    WDFDEVICE         hWdfDevPDO = MadFindPdoInOidList(pPhysDevObj, &SerialNo);
    WdfSpinLockRelease(ghPdoDevOidsLock);

    PPDO_DEVICE_DATA     pPdoData = MadBusPdoGetData(hWdfDevPDO);
	PSCATTER_GATHER_LIST pSgList = (PSCATTER_GATHER_LIST)&pPdoData->SgList;

	TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
		        "MadSimDmaTransactionInitializeUsingRequest...SerialNo=%d, hDmaXaxn=%p, hRequest=%p, Direxn=%d, pEvtProgramDmaFunxn=%p\n",
				pPdoData->SerialNo, hDmaXaxn, hRequest, (ULONG)Direxn, pEvtProgramDmaFunxn);

	pPdoData->pEvtProgramDmaFunxn = pEvtProgramDmaFunxn; 

	if (!(BOOLEAN)Direxn) //It's a read
		NtStatus = WdfRequestRetrieveOutputWdmMdl(hRequest, &pMDL);
	else
		NtStatus = WdfRequestRetrieveInputWdmMdl(hRequest, &pMDL);
	if (!NT_SUCCESS(NtStatus))
	    {
		TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
			        "MadSimDmaTransactionInitializeUsingRequest:WdfRequestRetrieveIoWdmMdl returned status=0x%X\n",
					NtStatus);
		return NtStatus;
	    }

	//Build the OS Scatter-Gather List by converting the MDL
	//
	for (pCurrMdlItem = pMDL; pCurrMdlItem != NULL; pCurrMdlItem = pNextMdlItem) 
	    {
		pNextMdlItem = pCurrMdlItem->Next;
		if (!(pCurrMdlItem->MdlFlags & MDL_PAGES_LOCKED)) 
		    {
			MmProbeAndLockPages(pCurrMdlItem, KernelMode, IoModifyAccess);
		    }

		SysAddr = MmGetMdlVirtualAddress(pCurrMdlItem);
		//
		PhysAddr = MmGetPhysicalAddress(SysAddr);
		pSgList->Elements[NumItems].Address = PhysAddr;
		//
		pSgList->Elements[NumItems].Length = MmGetMdlByteCount(pCurrMdlItem); 
		TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
		            "MadSimDmaTransactionInitializeUsingRequest: SysAddr=%p, PhysAddr=0x%X:%X, Len=%d\n",
					SysAddr, PhysAddr.HighPart,PhysAddr.LowPart, pSgList->Elements[NumItems].Length);
		NumItems++;
	    }

	pSgList->NumberOfElements = NumItems;

	//Complete the transaction context for XxxDmaTransactionExecute
	//
	pXaxnData->hRequest = hRequest;
	pXaxnData->Direxn   = Direxn;
	pXaxnData->pSgList  = pSgList; 

	return NtStatus;
}
//
/************************************************************************//**
* MadSimDmaTransactionExecute
*
* DESCRIPTION:
*    This is the simulation mode replacement for WdfDmaTransactionExecute
*    
* PARAMETERS: 
*     @param[in]  hDmaEnabler handle to the parent dma enabler  
*     @param[out] pDmaXaxn    pointer to the dma transaction handle
*     
* RETURNS:
*    @return      NtStatus    indicates success or reason for the failure
* 
***************************************************************************/
NTSTATUS MadSimDmaTransactionExecute(IN WDFDMATRANSACTION hDmaXaxn, IN OPTIONAL PVOID Context)
{
PMADSIM_DMA_TRANSACTION_CONTEXT pXaxnData =
                                WdfObjectGetTypedContext(hDmaXaxn, MADSIM_DMA_TRANSACTION_CONTEXT);
WDFDEVICE                       hFDO = pXaxnData->hFDO;
PDEVICE_OBJECT                  pPhysDevObj = WdfDeviceWdmGetPhysicalDevice(hFDO);
//
ULONG                           SerialNo;
NTSTATUS NtStatus = STATUS_SUCCESS;
BOOLEAN bRC;

    WdfSpinLockAcquire(ghPdoDevOidsLock);
    WDFDEVICE         hWdfDevPDO = MadFindPdoInOidList(pPhysDevObj, &SerialNo);
    WdfSpinLockRelease(ghPdoDevOidsLock);

    PPDO_DEVICE_DATA  pPdoData = MadBusPdoGetData(hWdfDevPDO);

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
 		        "MadSimDmaTransactionExecute...SerialNo=%d, hDmaXaxn=%p, pEvtProgramDmaFunxn=%p\n",
				pPdoData->SerialNo, hDmaXaxn, pPdoData->pEvtProgramDmaFunxn);

	bRC = 
	pPdoData->pEvtProgramDmaFunxn(hDmaXaxn, hFDO, Context, pXaxnData->Direxn, pXaxnData->pSgList);

	NtStatus = bRC ? STATUS_SUCCESS : STATUS_UNSUCCESSFUL;

	return NtStatus;
}
//
/************************************************************************//**
* MadSimDmaTransactionGetRequest
*
* DESCRIPTION:
*    This is the simulation mode replacement for WdfDmaTransactionGetRequest
*
* PARAMETERS:
*     @param[out] hDmaXaxn    handle to the dma transaction
*
* RETURNS:
*    @return      hRequest    handle to the parent/associated request
*
***************************************************************************/
WDFREQUEST MadSimDmaTransactionGetRequest(IN WDFDMATRANSACTION hDmaXaxn)

{
PMADSIM_DMA_TRANSACTION_CONTEXT pXaxnData = 
                                WdfObjectGetTypedContext(hDmaXaxn, MADSIM_DMA_TRANSACTION_CONTEXT);
WDFREQUEST                      hRequest = pXaxnData->hRequest;

	return hRequest;
}
//
/************************************************************************//**
* MadSimDmaTransactionGetBytesTransferred
*
* DESCRIPTION:
*    This is the simulation mode replacement for
*     WdfDmaTransactionGetBytesTransferred
*
* PARAMETERS:
*     @param[in]  hDmaXaxn    handle to the dma transaction
*     @param[out] pDmaXaxn    pointer to the dma transaction handle
*
* RETURNS:
*    @return      BytesXferd  nuber of bytes dma-transferred
*
***************************************************************************/

size_t  MadSimDmaTransactionGetBytesTransferred(IN WDFDMATRANSACTION hDmaXaxn)

{
PMADSIM_DMA_TRANSACTION_CONTEXT pXaxnData = 
                                WdfObjectGetTypedContext(hDmaXaxn, MADSIM_DMA_TRANSACTION_CONTEXT);
WDFDEVICE                       hFDO = pXaxnData->hFDO; 
PDEVICE_OBJECT                  pPhysDevObj = WdfDeviceWdmGetPhysicalDevice(hFDO);
//
ULONG                           SerialNo;

    WdfSpinLockAcquire(ghPdoDevOidsLock);
    WDFDEVICE         hWdfDevPDO = MadFindPdoInOidList(pPhysDevObj, &SerialNo);
    WdfSpinLockRelease(ghPdoDevOidsLock);

    PPDO_DEVICE_DATA  pPdoData = MadBusPdoGetData(hWdfDevPDO);
    PMADREGS          pMadRegs = pPdoData->pMadRegs;
    size_t            BytesXferd = (size_t)pMadRegs->DTBC; //Updated upon completion by our hardware

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
            	"MadSimDmaTransactionGetBytesTransferred...SerialNo=%d, hDmaXaxn=%p, BytesXferd=%d\n",
	            pPdoData->SerialNo, hDmaXaxn, (ULONG)BytesXferd);

	return BytesXferd;
}
//
BOOLEAN MadSimDmaTransactionDmaCompleted(IN WDFDMATRANSACTION hDmaXaxn, OUT NTSTATUS *pStatus)

{
PMADSIM_DMA_TRANSACTION_CONTEXT pXaxnData =
		                        WdfObjectGetTypedContext(hDmaXaxn, MADSIM_DMA_TRANSACTION_CONTEXT);
WDFDEVICE                       hFDO = pXaxnData->hFDO;
PDEVICE_OBJECT                  pPhysDevObj = WdfDeviceWdmGetPhysicalDevice(hFDO);
//
ULONG                           SerialNo;

    WdfSpinLockAcquire(ghPdoDevOidsLock);
    WDFDEVICE         hWdfDevPDO = MadFindPdoInOidList(pPhysDevObj, &SerialNo);
    WdfSpinLockRelease(ghPdoDevOidsLock);

    PPDO_DEVICE_DATA  pPdoData = MadBusPdoGetData(hWdfDevPDO);

    TraceEvents(TRACE_LEVEL_INFORMATION, MYDRIVER_ALL_INFO,
	            "MadSimDmaTransactionCompleted...SerialNo=%d, hDmaXaxn=%p\n",
	            pPdoData->SerialNo, hDmaXaxn);

    *pStatus = STATUS_SUCCESS;

	return TRUE; //Always in the prototype
}
//
/************************************************************************//**
* MadSimDmaTransactionGetDevice
*
* DESCRIPTION:
*    This is the simulation mode replacement for WdfDmaTransactionGetDevice
*
* PARAMETERS:
*     @param[out] hDmaXaxn    handle to the dma transaction
*
* RETURNS:
*    @return      hFDO     handle to the parent/associated device
*
***************************************************************************/
WDFDEVICE MadSimDmaTransactionGetDevice(IN WDFDMATRANSACTION hDmaXaxn)

{
PMADSIM_DMA_TRANSACTION_CONTEXT pXaxnData = 
                                WdfObjectGetTypedContext(hDmaXaxn, MADSIM_DMA_TRANSACTION_CONTEXT);
WDFDEVICE                       hFDO  = pXaxnData->hFDO;

	return hFDO;
}
#endif //KMDF_WONT_CREATE_DMA_ENABLER +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
