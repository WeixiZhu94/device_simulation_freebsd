/********1*********2*********3*********4*********5**********6*********7*********/
/*                                                                             */
/*  PRODUCT      : MAD Device Simulation Framework                             */
/*  COPYRIGHT    : (c) 2022 HTF Consulting                                     */
/*                                                                             */
/* This source code is provided by exclusive license for non-commercial use to */
/* XYZ Company                                                                 */
/*                                                                             */ 
/*******************************************************************************/
/*                                                                             */
/*  Exe file ID  : MadBus.sys                                                  */ 
/*                                                                             */
/*  Module  NAME : MadBus.h                                                    */
/*                                                                             */
/*  DESCRIPTION  : Definition of structures and function prototypes            */
/*                 Derived from WDK-Toaster\bus\bus.h                          */
/*                                                                             */
/*******************************************************************************/

//#define _AMD64_
#include <ntddk.h>
#include <wdf.h>
#define NTSTRSAFE_LIB
#include <ntstrsafe.h>
#include <ntintsafe.h>
#include <initguid.h>
#include "..\Includes\MadGUIDs.h"
#include "..\Inc\MadBusDdiQi.h"
//
#define SIMULATION_MODE   //Always true for the simulator - required for some common defines
#include "..\Includes\MadDefinition.h"
#include "..\Includes\MadBusConfig.h"
#include "..\Includes\MadBusIoctls.h"
#include "..\Includes\MadUtilFunxns.h"
#include "..\Includes\MadBusUsrIntBufrs.h"
#include "MadBusMof.h"
#include ".\MadBus\MadBusMC\MadBus.h"

extern "C" {
#include "..\Includes\MadRegFunxns.h"
}

#ifndef MadBus_H
#define MadBus_H

#define  GET_PREV_IOSTACK_LOCATION(X)  \
         (PIO_STACK_LOCATION)((ULONG_PTR)(sizeof(IO_STACK_LOCATION)) + (ULONG_PTR)X)

#define   MADBUS_POOL_TAG (ULONG) 'BdaM'
#define  BUSRESOURCENAME    L"MadBusWMI" //This must match the named MOFDATA item in the .RC file
#define MAX_INSTANCE_ID_LEN                       80

extern ULONG BusEnumDebugLevel;

typedef struct _MADBUS_WMI_DATA
    {
	//Room for other WMI data-block(s) / classes
	MadBusWmiInfo      InfoClassData;
	////Room for other WMI data-block(s) / classes
    } MADBUS_WMI_DATA, *PMDBUS_WMI_DATA;

// The device extension of the bus itself.  From whence the PDO's are born.
//
typedef struct _FDO_DEVICE_DATA
    {
	ULONG                        SerialNo;

	MADBUS_WMI_DATA              MadBusWmiData;

	MADBUS_DEVICE_CONFIG_DATA    DfltCnfgData;

	PVOID                        pDevicesBase;
	PHYSICAL_ADDRESS             liDevicesBase;
	ULONG                        OurVector;
	KIRQL                        OurIRQL;
	KAFFINITY                    OurAffinity;

    } FDO_DEVICE_DATA, *PFDO_DEVICE_DATA;
//
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(FDO_DEVICE_DATA, MadBusFdoGetData)

typedef struct _PDO_DEVICE_OIDS
    {
	PDEVICE_OBJECT  pPhysDevObj;
	WDFDEVICE       hPhysDevice;
    } PDO_DEVICE_OIDS, *PPDO_DEVICE_OIDS;
#define PDO_DEVICE_OIDS_DEFINED

// The goal of the identification and address description abstractions is that enough
// information is stored for a discovered device so that when it appears on the bus,
// the framework (with the help of the driver writer) can determine if it is a new or
// existing device.  The identification and address descriptions are opaque structures
// to the framework, they are private to the driver writer.  The only thing the framework
// knows about these descriptions is what their size is.
// The identification contains the bus specific information required to recognize
// an instance of a device on its the bus.  The identification information usually
// contains device IDs along with any serial or slot numbers.
// For some buses (like USB and PCI), the identification of the device is sufficient to
// address the device on the bus; in these instances there is no need for a separate
// address description.  Once reported, the identification description remains static
// for the lifetime of the device.  For example, the identification description that the
// PCI bus driver would use for a child would contain the vendor ID, device ID,
// subsystem ID, revision, and class for the device. This sample uses only identification
// description.
// On other busses (like 1394 and auto LUN SCSI), the device is assigned a dynamic
// address by the hardware (which may reassigned and updated periodically); in these
// instances the driver will use the address description to encapsulate this dynamic piece
// of data.    For example in a 1394 driver, the address description would contain the
// device's current generation count while the identification description would contain
// vendor name, model name, unit spec ID, and unit software version.
//
typedef struct _PDO_IDENTIFICATION_DESCRIPTION
    {
    WDF_CHILD_IDENTIFICATION_DESCRIPTION_HEADER Header; // should contain this header

    // Unique serail number of the device on the bus
    //
    ULONG SerialNo;

    size_t CchHardwareIds;

    __field_bcount(CchHardwareIds) PWCHAR HardwareIds;

    } PDO_IDENTIFICATION_DESCRIPTION, *PPDO_IDENTIFICATION_DESCRIPTION;

typedef struct _MADSIM_DMA_ENABLER_CONTEXT
    {
	WDFDEVICE             hFDO;
    } MADSIM_DMA_ENABLER_CONTEXT, *PMADSIM_DMA_ENABLER_CONTEXT;
//
WDF_DECLARE_CONTEXT_TYPE(MADSIM_DMA_ENABLER_CONTEXT)

typedef struct _MADSIM_DMA_TRANSACTION_CONTEXT
    {
	WDFDEVICE             hFDO;
	WDFDMAENABLER         hDmaEnabler;
	WDFREQUEST            hRequest;
	WDF_DMA_DIRECTION     Direxn;
	PSCATTER_GATHER_LIST  pSgList;
    } MADSIM_DMA_TRANSACTION_CONTEXT, *PMADSIM_DMA_TRANSACTION_CONTEXT;
//
WDF_DECLARE_CONTEXT_TYPE(MADSIM_DMA_TRANSACTION_CONTEXT)

// These defines below are for creating object names in the object data base 
//
#define MADBUS_NT_DEVICE_NAME_WSTR             L"\\Device\\MadBusPDOx"
#define MADBUS_NT_DEVICE_NAME_UNITID_INDX     17 //Index of this X  ^

// This is PDO device-extension.
//
typedef struct _PDO_DEVICE_DATA
    {
    // Unique serial number of the device on the bus
    ULONG               SerialNo;
	WDFDEVICE           hDevice;
	//
	PFDO_DEVICE_DATA    pFdoData;

    //Device interrupt thread Parameters
    HANDLE              hDevIntThread;
    KEVENT              evIntThreadExit;
	PETHREAD            pIntThreadObj;

    //Resource parameters
    //
    ULONG                     IDTindx;
    ULONG                     IntVector;
    KIRQL                     Irql;
    KAFFINITY                 IntAffinity;
    PHYSICAL_ADDRESS          liDevBase;
    PHYSICAL_ADDRESS          liDevPioRead;
    PHYSICAL_ADDRESS          liDevPioWrite;
    PHYSICAL_ADDRESS          liDeviceData;
    PMADREGS                  pMadRegs;
    PVOID                     pPioRead;
    PVOID                     pPioWrite;
	PVOID                     pReadCache;
    PVOID                     pWriteCache;
    PVOID                     pDeviceData;

    MADBUS_DEVICE_CONFIG_DATA BusPdoCnfgData;
    MAD_SIMULATION_INT_PARMS  MadSimIntParms;    

    #ifdef KMDF_WONT_CREATE_DMA_ENABLER
	PFN_WDF_PROGRAM_DMA    pEvtProgramDmaFunxn; 
	MADSIM_KMDF_DMA_FUNXNS MadSimDmaFunxns;
 
	UCHAR SgList[sizeof(SCATTER_GATHER_ELEMENT) * (MAD_DMA_MAX_SECTORS + 3)];
    #endif

	#ifdef TTIOD2PNP
    CM_PARTIAL_RESOURCE_DESCRIPTOR  CmPartlResrcDescs[MADDEV_TOTL_CM_RESOURCES];
    IO_RESOURCE_DESCRIPTOR          IoResrcDescs[MADDEV_TOTL_CM_RESOURCES];
    WDFIORESLIST                    hIoResrcList;
    #endif

    UCHAR               ResrcList[1000];     //TBD Plenty of space inline - need to optimize
    UCHAR               ResrcListXlatd[1000];
    } PDO_DEVICE_DATA, *PPDO_DEVICE_DATA;
//
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(PDO_DEVICE_DATA, MadBusPdoGetData)

// Prototypes of functions
//
extern "C" {
DRIVER_INITIALIZE          DriverEntry;
EVT_WDF_DRIVER_UNLOAD      MadBusEvtDriverUnload;
EVT_WDF_DRIVER_DEVICE_ADD  MadBusEvtDeviceAdd;
EVT_WDF_DEVICE_FILE_CREATE MadBusEvtFileCreate;
EVT_WDF_FILE_CLOSE         MadBusEvtFileClose;

EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL MadBusEvtIoDeviceControl;

EVT_WDF_CHILD_LIST_CREATE_DEVICE                        MadBusEvtDeviceListCreatePdo;
EVT_WDF_CHILD_LIST_IDENTIFICATION_DESCRIPTION_COMPARE   MadBusEvtChildListIdentificationDescriptionCompare;
EVT_WDF_CHILD_LIST_IDENTIFICATION_DESCRIPTION_CLEANUP   MadBusEvtChildListIdentificationDescriptionCleanup;
EVT_WDF_CHILD_LIST_IDENTIFICATION_DESCRIPTION_DUPLICATE MadBusEvtChildListIdentificationDescriptionDuplicate;

NTSTATUS MadBus_PlugInDevice(__in WDFDEVICE Device, __in PWCHAR HardwareIds, __in size_t CchHardwareIds, __in ULONG SerialNo);
NTSTATUS MadBus_UnPlugDevice(WDFDEVICE Device, ULONG SerialNo);
NTSTATUS MadBus_EjectDevice(WDFDEVICE Device, ULONG SerialNo);
NTSTATUS MadBus_CreatePdo(__in WDFDEVICE Device, __in PWDFDEVICE_INIT ChildInit, __in PWCHAR HardwareIds, __in ULONG SerialNo);
NTSTATUS MadBus_DoStaticEnumeration(IN WDFDEVICE Device);
VOID     MadBusPdoFreeResrcs(WDFDEVICE hChild, ULONG SerialNo);

// Interface functions
//
BOOLEAN MadBus_GetPowerLevel(IN   WDFDEVICE ChildDevice, OUT  PUCHAR Level);
BOOLEAN MadBus_SetPowerLevel(IN   WDFDEVICE ChildDevice, OUT  UCHAR Level);
BOOLEAN MadBus_IsSafetyLockEnabled(WDFDEVICE ChildDevice);

// Defined in MadBusWmi.c
//
NTSTATUS                             MadBus_WmiRegistration(WDFDEVICE hDevice);
EVT_WDF_WMI_INSTANCE_SET_ITEM        MadBusWmiEvtSetInfoInstanceDataItem;
EVT_WDF_WMI_INSTANCE_SET_INSTANCE    MadBusWmiEvtSetInfoInstanceData;
EVT_WDF_WMI_INSTANCE_QUERY_INSTANCE  MadBusWmiEvtQueryInfoInstanceData;
//
EVT_WDF_WMI_INSTANCE_QUERY_INSTANCE  MadBusWmiEvtInstanceQueryDevControl;
EVT_WDF_WMI_INSTANCE_EXECUTE_METHOD  MadBusWmiEvtInstance_DevCntlExecMethod;

//Additions to WDF-Toaster framework
//
KSTART_ROUTINE   MadPdoIntThread;
MADDEV_IO_TYPE   MadDevDetermineIo(PPDO_DEVICE_DATA pPdoData);
VOID             MadBusPdoProcessDevIo(PPDO_DEVICE_DATA pPdoData, MADDEV_IO_TYPE DevReqType);
VOID             MadBusPdoProcessDevSgDma(PPDO_DEVICE_DATA pPdoData, MADDEV_IO_TYPE DevReqType);
NTSTATUS         MadBus_SetPowerState(WDFDEVICE hDevice, PMADBUS_SET_POWER_STATE pSetPowerState);
//VOID             MadBus_PowerIrpCompletion(PDEVICE_OBJECT pDevObj, UCHAR MinorFunction,
//                                           POWER_STATE PowerState, PVOID pContext, PIO_STATUS_BLOCK pIoStatus); 

NTSTATUS MadBusEvtDevCntl_DevSimUsrInt(IN WDFQUEUE hQueue, IN WDFREQUEST hRequest, 
                                        IN size_t  OutBufrLen, IN size_t InBufrLen,
                                        IN ULONG  IoControlCode);
NTSTATUS MadBus_MapWholeDevice(PFDO_DEVICE_DATA pFdoData, 
                               PMADBUS_MAP_WHOLE_DEVICE pMapWholeDevice, ULONG SerialNo);

PVOID MadBus_AllocDeviceSet(IN PDRIVER_OBJECT pDrivrObj, IN PMADBUS_DEVICE_CONFIG_DATA pCnfgData, PULONG pNumDevices);
void  MadBusPdo_PlugCmResrcsIntoFdoStackLoc(PPDO_DEVICE_DATA pPdoData, PIRP pIRP, IN PIO_STACK_LOCATION pIoStackLoc); 
void  SetStaticCmResrcs(PPDO_DEVICE_DATA pPdoData); 
void  SetStaticIoResrcs(PPDO_DEVICE_DATA pPdoData); 

NTSTATUS
MadBusReadRegParms(IN PDRIVER_OBJECT pDrivrObj,   // Driver object
                   IN PUNICODE_STRING pParmPath,    // base path to keys
                   OUT PULONG pDevIRQL, OUT PULONG pIdtBaseDX, PBOOLEAN pbAffinityOn,
				   OUT PULONG pNumFilters, OUT PULONG pMaxDevices, OUT PULONG pMadDevDataXtent); 

NTSTATUS MadBusReadRegConfig(IN WDFDEVICE  hDevice,   
                             IN PUNICODE_STRING pCnfgPath, 
                             OUT PMADBUS_DEVICE_CONFIG_DATA pCnfgData); 

WDFDEVICE      MadFindPdoInOidList(PDEVICE_OBJECT pPhysDevObj, PULONG pSerialNo);

// WDF-prototyped functions;
//
EVT_WDF_DEVICE_PREPARE_HARDWARE              MadBusPdoEvtPrepareHardware;
EVT_WDFDEVICE_WDM_IRP_PREPROCESS             MadBusPdoEvtWdmIrpPreprocess;
EVT_WDF_DEVICE_D0_ENTRY                      MadBusPdoEvtD0Entry;
EVT_WDF_DEVICE_D0_EXIT                       MadBusPdoEvtD0Exit;
EVT_WDF_DEVICE_RESOURCES_QUERY               MadBusPdoEvtResrcsQuery;
EVT_WDF_DEVICE_RESOURCE_REQUIREMENTS_QUERY   MadBusPdoEvtResrcReqsQuery;

#ifdef KMDF_WONT_CREATE_DMA_ENABLER 
NTSTATUS   MadSimDmaEnablerCreate(IN WDFDEVICE Device, IN PWDF_DMA_ENABLER_CONFIG Config, IN OPTIONAL PWDF_OBJECT_ATTRIBUTES Attributes,
	                              OUT WDFDMAENABLER* DmaEnablerHandle);
VOID       MadSimDmaEnablerSetMaximumScatterGatherElements(IN WDFDMAENABLER DmaEnabler, IN size_t MaximumFragments);
NTSTATUS   MadSimDmaTransactionCreate(IN WDFDMAENABLER DmaEnabler, IN OPTIONAL WDF_OBJECT_ATTRIBUTES *Attributes, OUT WDFDMATRANSACTION *DmaTransaction);
NTSTATUS   MadSimDmaTransactionInitializeUsingRequest(IN WDFDMATRANSACTION DmaTransaction, IN WDFREQUEST Request,
	                                                  IN PFN_WDF_PROGRAM_DMA EvtProgramDmaFunction, IN WDF_DMA_DIRECTION DmaDirection);
NTSTATUS   MadSimDmaTransactionExecute(IN WDFDMATRANSACTION DmaTransaction, IN OPTIONAL PVOID Context);
WDFREQUEST MadSimDmaTransactionGetRequest(IN WDFDMATRANSACTION DmaTransaction);
size_t     MadSimDmaTransactionGetBytesTransferred(IN WDFDMATRANSACTION DmaTransaction);
BOOLEAN    MadSimDmaTransactionDmaCompleted(IN WDFDMATRANSACTION DmaTransaction, OUT NTSTATUS *Status);
WDFDEVICE  MadSimDmaTransactionGetDevice(IN WDFDMATRANSACTION hDmaXaxn);
#endif
} // End extern "C"cls
#endif

