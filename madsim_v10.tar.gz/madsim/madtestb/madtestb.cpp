//============================================================================
// Name        : madtestb.cpp
// Author      : htf
// Version     :
// Copyright   : (c) 2018
// Description : Hello World in C++, Ansi-style
//============================================================================

#define  BIO
#include "../madtest/madtest.cpp"
